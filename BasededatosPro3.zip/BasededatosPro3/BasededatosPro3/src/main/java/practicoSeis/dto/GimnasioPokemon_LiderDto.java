package practicoSeis.dto;

public class GimnasioPokemon_LiderDto {
    private int ID_GimnacioPokemon;
    private String Pokemon_del_lider;

    public GimnasioPokemon_LiderDto(int ID_GimnacioPokemon, String Pokemon_del_lider) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
        this.Pokemon_del_lider = Pokemon_del_lider;
    }

    public int getID_GimnacioPokemon() {
        return ID_GimnacioPokemon;
    }

    public void setID_GimnacioPokemon(int ID_GimnacioPokemon) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }

    public String getPokemon_del_lider() {
        return Pokemon_del_lider;
    }

    public void setPokemon_del_lider(String Pokemon_del_lider) {
        this.Pokemon_del_lider = Pokemon_del_lider;
    }
}