package practicoSeis.dto;

public class TablaPersonaDto {
    //Data Transfer Objects
    private int id;
    private String nombre;
    private int alturacm;
    private float pesokg;

    public TablaPersonaDto(int id, String nombre, int altura, float peso) {
        this.id = id;
        this.nombre = nombre;
        this.alturacm = altura;
        this.pesokg = peso;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAlturacm() {
        return alturacm;
    }

    public void setAlturacm(int alturacm) {
        this.alturacm = alturacm;
    }

    public float getPesokg() {
        return pesokg;
    }

    public void setPesokg(float pesokg) {
        this.pesokg = pesokg;
    }
}
