package practicoSeis.dto;

public class Lider_GymDto {
    private String stipo;
    private String sestrategia;
    private String shabilidad;
    private int Habitante_ID;
    private int ID_GimnacioPokemon;

    public Lider_GymDto(String stipo, String sestrategia, String shabilidad, int Habitante_ID, int ID_GimnacioPokemon) {
        this.stipo = stipo;
        this.sestrategia = sestrategia;
        this.shabilidad = shabilidad;
        this.Habitante_ID = Habitante_ID;
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }

    public String getStipo() {
        return stipo;
    }

    public void setStipo(String stipo) {
        this.stipo = stipo;
    }

    public String getSestrategia() {
        return sestrategia;
    }

    public void setSestrategia(String sestrategia) {
        this.sestrategia = sestrategia;
    }

    public String getShabilidad() {
        return shabilidad;
    }

    public void setShabilidad(String shabilidad) {
        this.shabilidad = shabilidad;
    }

    public int getHabitante_ID() {
        return Habitante_ID;
    }

    public void setHabitante_ID(int Habitante_ID) {
        this.Habitante_ID = Habitante_ID;
    }

    public int getID_GimnacioPokemon() {
        return ID_GimnacioPokemon;
    }

    public void setID_GimnacioPokemon(int ID_GimnacioPokemon) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }
}
