package practicoSeis.dto;

public class PuebloDto {
}
