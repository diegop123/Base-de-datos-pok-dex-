package practicoSeis.dto;

public class PokemonDto {
    private int ID_Pokemon;
    private String Snombre;
    private String Stipo;
    private String Sdescripcion;
    private String Sestado;
    private int Habitante_ID;

    public PokemonDto(int ID_Pokemon, String Snombre, String Stipo, String Sdescripcion, String Sestado, int Habitante_ID) {
        this.ID_Pokemon = ID_Pokemon;
        this.Snombre = Snombre;
        this.Stipo = Stipo;
        this.Sdescripcion = Sdescripcion;
        this.Sestado = Sestado;
        this.Habitante_ID = Habitante_ID;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public String getSnombre() {
        return Snombre;
    }

    public void setSnombre(String Snombre) {
        this.Snombre = Snombre;
    }

    public String getStipo() {
        return Stipo;
    }

    public void setStipo(String Stipo) {
        this.Stipo = Stipo;
    }

    public String getSdescripcion() {
        return Sdescripcion;
    }

    public void setSdescripcion(String Sdescripcion) {
        this.Sdescripcion = Sdescripcion;
    }

    public String getSestado() {
        return Sestado;
    }

    public void setSestado(String Sestado) {
        this.Sestado = Sestado;
    }

    public int getHabitante_ID() {
        return Habitante_ID;
    }

    public void setHabitante_ID(int Habitante_ID) {
        this.Habitante_ID = Habitante_ID;
    }
}
