package practicoSeis.dto;

public class EntrenadorDto {
    private int nEXP;
    private String sestrategia;
    private String shistoria;
    private int Habitante_ID;

    public EntrenadorDto(int nEXP, String sestrategia, String shistoria, int Habitante_ID) {
        this.nEXP = nEXP;
        this.sestrategia = sestrategia;
        this.shistoria = shistoria;
        this.Habitante_ID = Habitante_ID;
    }

    public int getnEXP() {
        return nEXP;
    }

    public void setnEXP(int nEXP) {
        this.nEXP = nEXP;
    }

    public String getSestrategia() {
        return sestrategia;
    }

    public void setSestrategia(String sestrategia) {
        this.sestrategia = sestrategia;
    }

    public String getShistoria() {
        return shistoria;
    }

    public void setShistoria(String shistoria) {
        this.shistoria = shistoria;
    }

    public int getHabitante_ID() {
        return Habitante_ID;
    }

    public void setHabitante_ID(int habitante_ID) {
        Habitante_ID = habitante_ID;
    }
}
