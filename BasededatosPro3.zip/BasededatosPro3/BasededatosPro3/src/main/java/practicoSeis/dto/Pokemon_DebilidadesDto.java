package practicoSeis.dto;

public class Pokemon_DebilidadesDto {
    private int ID_Pokemon;
    private int nDebilidades;

    public Pokemon_DebilidadesDto(int ID_Pokemon, int nDebilidades) {
        this.ID_Pokemon = ID_Pokemon;
        this.nDebilidades = nDebilidades;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public int getnDebilidades() {
        return nDebilidades;
    }

    public void setnDebilidades(int nDebilidades) {
        this.nDebilidades = nDebilidades;
    }
}
