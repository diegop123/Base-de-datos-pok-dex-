package practicoSeis.dto;

public class PersonaDto {
    private int nID_Batalla;
    private int nTurnosFinalizados;
    private String sEstado;
    private String sGanador;
    private String nResultado;
    private String sEventos;

    private int nDuracion;
    private int ID_Entrenador_Batalla;
    private int ID_Entrenador;


    public PersonaDto(int nID_Batalla, int nTurnosFinalizados,String sEstado,String sGanador,
                      String sEventos, String nResultado, int nDuracion, int ID_Entrenador_Batalla, int ID_Entrenador) {
        this.nID_Batalla = nID_Batalla;
        this.nTurnosFinalizados = nTurnosFinalizados;
        this.sEstado = sEstado;
        this.sGanador = sGanador;
        this.sEventos = sEventos;
        this.nResultado = nResultado;
        this.nDuracion = nDuracion;
        this.ID_Entrenador_Batalla = ID_Entrenador_Batalla;
        this.ID_Entrenador = ID_Entrenador;
    }

    public int getnID_Batalla() {
        return nID_Batalla;
    }

    public void setnID_Batalla(int nID_Batalla) {
        this.nID_Batalla = nID_Batalla;
    }

    public int getnTurnosFinalizados() {
        return nTurnosFinalizados;
    }

    public void setnTurnosFinalizados(int nTurnosFinalizados) {
        this.nTurnosFinalizados = nTurnosFinalizados;
    }

    public String getsEstado() {
        return sEstado;
    }

    public void setsEstado(String sEstado) {
        this.sEstado = sEstado;
    }

    public String getsGanador() {
        return sGanador;
    }

    public void setsGanador(String sGanador) {
        this.sGanador = sGanador;
    }

    public String getnResultado() {
        return nResultado;
    }

    public void setnResultado(String nResultado) {
        this.nResultado = nResultado;
    }

    public String getsEventos() {
        return sEventos;
    }

    public void setsEventos(String sEventos) {
        this.sEventos = sEventos;
    }

    public int getnDuracion() {
        return nDuracion;
    }

    public void setnDuracion(int nDuracion) {
        this.nDuracion = nDuracion;
    }

    public int getID_Entrenador_Batalla() {
        return ID_Entrenador_Batalla;
    }

    public void setID_Entrenador_Batalla(int ID_Entrenador_Batalla) {
        this.ID_Entrenador_Batalla = ID_Entrenador_Batalla;
    }

    public int getID_Entrenador() {
        return ID_Entrenador;
    }

    public void setID_Entrenador(int ID_Entrenador) {
        this.ID_Entrenador = ID_Entrenador;
    }


}
