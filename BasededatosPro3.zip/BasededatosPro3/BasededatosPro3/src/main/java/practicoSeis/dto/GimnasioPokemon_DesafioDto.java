package practicoSeis.dto;

public class GimnasioPokemon_DesafioDto {
    private int ID_GimnacioPokemon;
    private String desafio;

    public GimnasioPokemon_DesafioDto(int ID_GimnacioPokemon, String desafio) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
        this.desafio = desafio;
    }

    public int getID_GimnacioPokemon() {
        return ID_GimnacioPokemon;
    }

    public void setID_GimnacioPokemon(int ID_GimnacioPokemon) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }

    public String getDesafio() {
        return desafio;
    }

    public void setDesafio(String desafio) {
        this.desafio = desafio;
    }
}
