package practicoSeis.dto;


public class Pokemon_EvolucionDto {
    private int ID_Pokemon;
    private int nEvolucion;

    public Pokemon_EvolucionDto(int ID_Pokemon, int nEvolucion) {
        this.ID_Pokemon = ID_Pokemon;
        this.nEvolucion = nEvolucion;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public int getnEvolucion() {
        return nEvolucion;
    }

    public void setnEvolucion(int nEvolucion) {
        this.nEvolucion = nEvolucion;
    }
}
