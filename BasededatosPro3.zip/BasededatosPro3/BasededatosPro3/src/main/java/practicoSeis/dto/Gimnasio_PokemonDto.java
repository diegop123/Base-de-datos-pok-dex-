package practicoSeis.dto;


public class Gimnasio_PokemonDto {
    private int ID_GimnasioPokemon;
    private String snombre;
    private int ncaracteristicas_espaciales;
    private String ID_pueblo;

    public Gimnasio_PokemonDto(int ID_GimnasioPokemon, String snombre, int ncaracteristicas_espaciales, String ID_pueblo) {
        this.ID_GimnasioPokemon = ID_GimnasioPokemon;
        this.snombre = snombre;
        this.ncaracteristicas_espaciales = ncaracteristicas_espaciales;
        this.ID_pueblo = ID_pueblo;
    }

    public int getID_GimnasioPokemon() {
        return ID_GimnasioPokemon;
    }

    public void setID_GimnasioPokemon(int ID_GimnasioPokemon) {
        this.ID_GimnasioPokemon = ID_GimnasioPokemon;
    }

    public String getSnombre() {
        return snombre;
    }

    public void setSnombre(String snombre) {
        this.snombre = snombre;
    }

    public int getNcaracteristicas_espaciales() {
        return ncaracteristicas_espaciales;
    }

    public void setNcaracteristicas_espaciales(int ncaracteristicas_espaciales) {
        this.ncaracteristicas_espaciales = ncaracteristicas_espaciales;
    }

    public String getID_pueblo() {
        return ID_pueblo;
    }

    public void setID_pueblo(String ID_pueblo) {
        this.ID_pueblo = ID_pueblo;
    }
}
