package practicoSeis.dto;

public class EquipoPokemon_BatallaDto {
    private int ID_EquipoPokemon;
    private int ID_Batalla;

    public EquipoPokemon_BatallaDto(int ID_EquipoPokemon, int ID_Batalla) {
        this.ID_EquipoPokemon = ID_EquipoPokemon;
        this.ID_Batalla = ID_Batalla;
    }

    public int getID_EquipoPokemon() {
        return ID_EquipoPokemon;
    }

    public void setID_EquipoPokemon(int ID_EquipoPokemon) {
        this.ID_EquipoPokemon = ID_EquipoPokemon;
    }

    public int getID_Batalla() {
        return ID_Batalla;
    }

    public void setID_Batalla(int ID_Batalla) {
        this.ID_Batalla = ID_Batalla;
    }
}
