package practicoSeis.dto;

public class Equipo_PokemonDto {
    private int ID_equipoP;
    private int ID_entrenador;
    private int ID_pokemon;

    public Equipo_PokemonDto(int ID_equipoP, int ID_entrenador, int ID_pokemon) {
        this.ID_equipoP = ID_equipoP;
        this.ID_entrenador = ID_entrenador;
        this.ID_pokemon = ID_pokemon;
    }

    public int getID_equipoP() {
        return ID_equipoP;
    }

    public void setID_equipoP(int ID_equipoP) {
        this.ID_equipoP = ID_equipoP;
    }

    public int getID_entrenador() {
        return ID_entrenador;
    }

    public void setID_entrenador(int ID_entrenador) {
        this.ID_entrenador = ID_entrenador;
    }

    public int getID_pokemon() {
        return ID_pokemon;
    }

    public void setID_pokemon(int ID_pokemon) {
        this.ID_pokemon = ID_pokemon;
    }
}

