package practicoSeis.dto;

public class MedallaDto {
    private int Registro;
    private String Nombre;
    private String Requisitos;
    private String diseño;
    private String historia;
    private String significado;
    private int ID_GimnacioPokemon;

    public MedallaDto(int Registro, String Nombre, String Requisitos, String diseño, String historia, String significado, int ID_GimnacioPokemon) {
        this.Registro = Registro;
        this.Nombre = Nombre;
        this.Requisitos = Requisitos;
        this.diseño = diseño;
        this.historia = historia;
        this.significado = significado;
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }

    public int getRegistro() {
        return Registro;
    }

    public void setRegistro(int Registro) {
        this.Registro = Registro;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getRequisitos() {
        return Requisitos;
    }

    public void setRequisitos(String Requisitos) {
        this.Requisitos = Requisitos;
    }

    public String getDiseño() {
        return diseño;
    }

    public void setDiseño(String diseño) {
        this.diseño = diseño;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    public String getSignificado() {
        return significado;
    }

    public void setSignificado(String significado) {
        this.significado = significado;
    }

    public int getID_GimnacioPokemon() {
        return ID_GimnacioPokemon;
    }

    public void setID_GimnacioPokemon(int ID_GimnacioPokemon) {
        this.ID_GimnacioPokemon = ID_GimnacioPokemon;
    }
}
