package practicoSeis.dto;

public class Pokemon_FortalezasDto {
    private int ID_Pokemon;
    private int nFortalezas;

    public Pokemon_FortalezasDto(int ID_Pokemon, int nFortalezas) {
        this.ID_Pokemon = ID_Pokemon;
        this.nFortalezas = nFortalezas;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public int getnFortalezas() {
        return nFortalezas;
    }

    public void setnFortalezas(int nFortalezas) {
        this.nFortalezas = nFortalezas;
    }
}
