package practicoSeis.dto;

public class Logros_EntrenadorDto {
    private int ID_Entrenador;
    private int ID_Logro;

    public Logros_EntrenadorDto(int ID_Entrenador, int ID_Logro) {
        this.ID_Entrenador = ID_Entrenador;
        this.ID_Logro = ID_Logro;
    }

    public int getID_Entrenador() {
        return ID_Entrenador;
    }

    public void setID_Entrenador(int ID_Entrenador) {
        this.ID_Entrenador = ID_Entrenador;
    }

    public int getID_Logro() {
        return ID_Logro;
    }

    public void setID_Logro(int ID_Logro) {
        this.ID_Logro = ID_Logro;
    }
}
