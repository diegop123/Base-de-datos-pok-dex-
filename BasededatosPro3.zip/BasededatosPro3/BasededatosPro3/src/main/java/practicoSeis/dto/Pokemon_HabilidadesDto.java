package practicoSeis.dto;

public class Pokemon_HabilidadesDto {
    private int ID_Pokemon;
    private String Habilidades;

    public Pokemon_HabilidadesDto(int ID_Pokemon, String Habilidades) {
        this.ID_Pokemon = ID_Pokemon;
        this.Habilidades = Habilidades;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public String getHabilidades() {
        return Habilidades;
    }

    public void setHabilidades(String Habilidades) {
        this.Habilidades = Habilidades;
    }
}
