package practicoSeis.dto;

import java.sql.*;

public class HabitanteDto {
    private int CI;
    private String Snombre;
    private char Ssexo;
    private int Nedad;
    private Date NfechaNam;
    private String ID_pueblo;

    public HabitanteDto(int CI, String Snombre, char Ssexo, int Nedad, Date NfechaNam, String ID_pueblo) {
        this.CI = CI;
        this.Snombre = Snombre;
        this.Ssexo = Ssexo;
        this.Nedad = Nedad;
        this.NfechaNam = NfechaNam;
        this.ID_pueblo = ID_pueblo;
    }

    public int getCI() {
        return CI;
    }

    public void setCI(int CI) {
        this.CI = CI;
    }

    public String getSnombre() {
        return Snombre;
    }

    public void setSnombre(String Snombre) {
        this.Snombre = Snombre;
    }

    public char getSsexo() {
        return Ssexo;
    }

    public void setSsexo(char Ssexo) {
        this.Ssexo = Ssexo;
    }

    public int getNedad() {
        return Nedad;
    }

    public void setNedad(int Nedad) {
        this.Nedad = Nedad;
    }

    public Date getNfechaNam() {
        return NfechaNam;
    }

    public void setNfechaNam(Date NfechaNam) {
        this.NfechaNam = NfechaNam;
    }

    public String getID_pueblo() {
        return ID_pueblo;
    }

    public void setID_pueblo(String ID_pueblo) {
        this.ID_pueblo = ID_pueblo;
    }
}
