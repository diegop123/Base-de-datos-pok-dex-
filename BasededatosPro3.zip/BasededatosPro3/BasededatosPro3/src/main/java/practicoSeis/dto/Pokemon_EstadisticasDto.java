package practicoSeis.dto;

public class Pokemon_EstadisticasDto {
    private int ID_Pokemon;
    private int Nsalud;
    private int Nataque;
    private int Ndefensa;
    private int Nvelocidad;
    private String Sestadisticas;

    public Pokemon_EstadisticasDto(int ID_Pokemon, int Nsalud, int Nataque, int Ndefensa, int Nvelocidad, String Sestadisticas) {
        this.ID_Pokemon = ID_Pokemon;
        this.Nsalud = Nsalud;
        this.Nataque = Nataque;
        this.Ndefensa = Ndefensa;
        this.Nvelocidad = Nvelocidad;
        this.Sestadisticas = Sestadisticas;
    }

    public int getID_Pokemon() {
        return ID_Pokemon;
    }

    public void setID_Pokemon(int ID_Pokemon) {
        this.ID_Pokemon = ID_Pokemon;
    }

    public int getNsalud() {
        return Nsalud;
    }

    public void setNsalud(int Nsalud) {
        this.Nsalud = Nsalud;
    }

    public int getNataque() {
        return Nataque;
    }

    public void setNataque(int Nataque) {
        this.Nataque = Nataque;
    }

    public int getNdefensa() {
        return Ndefensa;
    }

    public void setNdefensa(int Ndefensa) {
        this.Ndefensa = Ndefensa;
    }

    public int getNvelocidad() {
        return Nvelocidad;
    }

    public void setNvelocidad(int Nvelocidad) {
        this.Nvelocidad = Nvelocidad;
    }

    public String getSestadisticas() {
        return Sestadisticas;
    }

    public void setSestadisticas(String Sestadisticas) {
        this.Sestadisticas = Sestadisticas;
    }
}
