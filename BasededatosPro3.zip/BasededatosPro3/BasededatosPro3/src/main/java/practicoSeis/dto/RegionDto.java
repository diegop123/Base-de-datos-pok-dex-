package practicoSeis.dto;

public class RegionDto {
}
