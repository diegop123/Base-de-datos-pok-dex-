package practicoSeis.dto;

public class Poke_BallDto {
    private int nID;
    private String sTipo;
    private String sDescripcion;
    private int nCaracteristicas_Especiales;
    private int nPropabilidad_de_captura;
    private String sObtencion;
    private String sDiseño;
    private int ID_Entrenador;

    public Poke_BallDto(int nID, String sTipo, String sDescripcion, int nCaracteristicas_Especiales, int nPropabilidad_de_captura, String sObtencion, String sDiseño, int ID_Entrenador) {
        this.nID = nID;
        this.sTipo = sTipo;
        this.sDescripcion = sDescripcion;
        this.nCaracteristicas_Especiales = nCaracteristicas_Especiales;
        this.nPropabilidad_de_captura = nPropabilidad_de_captura;
        this.sObtencion = sObtencion;
        this.sDiseño = sDiseño;
        this.ID_Entrenador = ID_Entrenador;
    }

    public int getnID() {
        return nID;
    }

    public void setnID(int nID) {
        this.nID = nID;
    }

    public String getsTipo() {
        return sTipo;
    }

    public void setsTipo(String sTipo) {
        this.sTipo = sTipo;
    }

    public String getsDescripcion() {
        return sDescripcion;
    }

    public void setsDescripcion(String sDescripcion) {
        this.sDescripcion = sDescripcion;
    }

    public int getnCaracteristicas_Especiales() {
        return nCaracteristicas_Especiales;
    }

    public void setnCaracteristicas_Especiales(int nCaracteristicas_Especiales) {
        this.nCaracteristicas_Especiales = nCaracteristicas_Especiales;
    }

    public int getnPropabilidad_de_captura() {
        return nPropabilidad_de_captura;
    }

    public void setnPropabilidad_de_captura(int nPropabilidad_de_captura) {
        this.nPropabilidad_de_captura = nPropabilidad_de_captura;
    }

    public String getsObtencion() {
        return sObtencion;
    }

    public void setsObtencion(String sObtencion) {
        this.sObtencion = sObtencion;
    }

    public String getsDiseño() {
        return sDiseño;
    }

    public void setsDiseño(String sDiseño) {
        this.sDiseño = sDiseño;
    }

    public int getID_Entrenador() {
        return ID_Entrenador;
    }

    public void setID_Entrenador(int ID_Entrenador) {
        this.ID_Entrenador = ID_Entrenador;
    }
}
