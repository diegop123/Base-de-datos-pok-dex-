package practicoSeis.dto;

public class Medalla_EntrenadorDto {
    private int ID_entrenador;
    private int ID_Medalla;

    public Medalla_EntrenadorDto(int ID_entrenador, int ID_Medalla) {
        this.ID_entrenador = ID_entrenador;
        this.ID_Medalla = ID_Medalla;
    }

    public int getID_entrenador() {
        return ID_entrenador;
    }

    public void setID_entrenador(int ID_entrenador) {
        this.ID_entrenador = ID_entrenador;
    }

    public int getID_Medalla() {
        return ID_Medalla;
    }

    public void setID_Medalla(int ID_Medalla) {
        this.ID_Medalla = ID_Medalla;
    }
}
