package practicoSeis.dto;

public class Entrenador_BatallaDto {
    private int id;
    private int Entrenador_ID;
    private int Batalla_ID;

    public Entrenador_BatallaDto(int id, int Entrenador_ID, int Batalla_ID) {
        this.id = id;
        this.Entrenador_ID = Entrenador_ID;
        this.Batalla_ID = Batalla_ID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEntrenador_ID() {
        return Entrenador_ID;
    }

    public void setEntrenador_ID(int Entrenador_ID) {
        this.Entrenador_ID = Entrenador_ID;
    }

    public int getBatalla_ID() {
        return Batalla_ID;
    }

    public void setBatalla_ID(int Batalla_ID) {
        this.Batalla_ID = Batalla_ID;
    }
}

