package practicoSeis;

import practicoSeis.dao.Poke_BallDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Poke_BallDaoMysql;
import practicoSeis.dto.Poke_BallDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPoke_ball extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Poke_BallDao dao = FactoryDao.obtenerOCrear().newPoke_BallDao();

    public TablaPoke_ball() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"nID", "sTipo", "sDescripcion", "nCaracteristicas_Especiales", "nPropabilidad_de_captura", "sObtencion", "sDiseño", "ID_Entrenador"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Poke_BallDaoMysql dao = new Poke_BallDaoMysql();
        Lista<Poke_BallDto> personas = dao.get();

        for (Poke_BallDto persona : personas) {
            Object[] rowData = {
                    persona.getnID(),
                    persona.getsTipo(),
                    persona.getsDescripcion(),
                    persona.getnCaracteristicas_Especiales(),
                    persona.getnPropabilidad_de_captura(),
                    persona.getsObtencion(),
                    persona.getsDiseño(),
                    persona.getID_Entrenador()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object nID = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) nID); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String nIDStr = JOptionPane.showInputDialog(null, "Por favor, introduce nID:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (nIDStr == null || nIDStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún nID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sTipo = JOptionPane.showInputDialog(null, "Por favor, introduce sTipo:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sTipo == null || sTipo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna sTipo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sDescripcion = JOptionPane.showInputDialog(null, "Por favor, introduce sDescripcion:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sDescripcion == null || sDescripcion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna sDescripcion.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nCaracteristicas_EspecialesStr = JOptionPane.showInputDialog(null, "Por favor, introduce nCaracteristicas_Especiales:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (nCaracteristicas_EspecialesStr == null || nCaracteristicas_EspecialesStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna nCaracteristicas_Especiales.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nPropabilidad_de_capturaStr = JOptionPane.showInputDialog(null, "Por favor, introduce nPropabilidad_de_captura:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (nPropabilidad_de_capturaStr == null || nPropabilidad_de_capturaStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna nPropabilidad_de_captura.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sObtencion = JOptionPane.showInputDialog(null, "Por favor, introduce sObtencion:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sObtencion == null || sObtencion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna sObtencion.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sDiseño = JOptionPane.showInputDialog(null, "Por favor, introduce sDiseño:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sDiseño == null || sDiseño.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna sDiseño.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ID_EntrenadorStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_Entrenador:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_EntrenadorStr == null || ID_EntrenadorStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_Entrenador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int nID;
        int nCaracteristicas_Especiales;
        int nPropabilidad_de_captura;
        int ID_Entrenador;

        try {
            nID = Integer.parseInt(nIDStr);
            nCaracteristicas_Especiales = Integer.parseInt(nCaracteristicas_EspecialesStr);
            nPropabilidad_de_captura = Integer.parseInt(nPropabilidad_de_capturaStr);
            ID_Entrenador = Integer.parseInt(ID_EntrenadorStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Poke_BallDto entrenadorExistente = dao.getById(nID);
        // Verificar si el nID ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El nID ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el nID ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == nID) {
                JOptionPane.showMessageDialog(null, "El nID ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nPropabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nPropabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador});
    }

    public void testDelete(int nID) {
        Poke_BallDao dao = FactoryDao.obtenerOCrear().newPoke_BallDao();
        dao.delete(nID);
    }

    public void testInsert(int nID, String sTipo, String sDescripcion, int nCaracteristicas_Especiales, int nPropabilidad_de_captura, String sObtencion, String sDiseño, int ID_Entrenador) {
        Poke_BallDao dao = FactoryDao.obtenerOCrear().newPoke_BallDao();
        Poke_BallDto nuevo = new Poke_BallDto(nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nPropabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador);
        dao.insert(nuevo);
    }
}
