package practicoSeis;


import practicoSeis.dao.MedallaDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.MedallaDaoMysql;
import practicoSeis.dto.MedallaDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaMedalla extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private MedallaDao dao = FactoryDao.obtenerOCrear().newMedallaDao();

    public TablaMedalla() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"Registro", "Nombre", "Requisitos", "diseño", "historia", "significado", "ID_GimnacioPokemon"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        MedallaDaoMysql dao = new MedallaDaoMysql();
        Lista<MedallaDto> personas = dao.get();

        for (MedallaDto persona : personas) {
            Object[] rowData = {
                    persona.getRegistro(),
                    persona.getNombre(),
                    persona.getRequisitos(),
                    persona.getDiseño(),
                    persona.getHistoria(),
                    persona.getSignificado(),
                    persona.getID_GimnacioPokemon()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object Registro = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) Registro); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String RegistroStr = JOptionPane.showInputDialog(null, "Por favor, introduce Registro:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (RegistroStr == null || RegistroStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Registro.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Nombre = JOptionPane.showInputDialog(null, "Por favor, introduce Nombre:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Nombre == null || Nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Nombre.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Requisitos = JOptionPane.showInputDialog(null, "Por favor, introduce Requisitos:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Requisitos == null || Requisitos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Requisitos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String diseño = JOptionPane.showInputDialog(null, "Por favor, introduce diseño:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (diseño == null || diseño.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún diseño.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String historia = JOptionPane.showInputDialog(null, "Por favor, introduce historia:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (historia == null || historia.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna historia.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String significado = JOptionPane.showInputDialog(null, "Por favor, introduce significado:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (significado == null || significado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún significado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ID_GimnacioPokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_GimnacioPokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_GimnacioPokemonStr == null || ID_GimnacioPokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_GimnacioPokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int Registro;
        int ID_GimnacioPokemon;

        try {
            Registro = Integer.parseInt(RegistroStr);
            ID_GimnacioPokemon = Integer.parseInt(ID_GimnacioPokemonStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MedallaDto entrenadorExistente = dao.getById(Registro);
        // Verificar si el Registro ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El Registro ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el Registro ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == Registro) {
                JOptionPane.showMessageDialog(null, "El Registro ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon});
    }

    public void testDelete(int Registro) {
        MedallaDao dao = FactoryDao.obtenerOCrear().newMedallaDao();
        dao.delete(Registro);
    }

    public void testInsert(int Registro, String Nombre, String Requisitos, String diseño, String historia, String significado, int ID_GimnacioPokemon) {
        MedallaDao dao = FactoryDao.obtenerOCrear().newMedallaDao();
        MedallaDto nuevo = new MedallaDto(Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon);
        dao.insert(nuevo);
    }
}
