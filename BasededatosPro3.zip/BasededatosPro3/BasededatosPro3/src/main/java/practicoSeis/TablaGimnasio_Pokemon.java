package practicoSeis;

import practicoSeis.dao.Gimnasio_PokemonDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Gimnasio_PokemonDaoMysql;
import practicoSeis.dto.Gimnasio_PokemonDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaGimnasio_Pokemon extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Gimnasio_PokemonDao dao = FactoryDao.obtenerOCrear().newGimnasio_PokemonDao();

    public TablaGimnasio_Pokemon() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_GimnacioPokemon", "snombre", "ncaracteristicas_espaciales", "ID_pueblo"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Gimnasio_PokemonDaoMysql dao = new Gimnasio_PokemonDaoMysql();
        Lista<Gimnasio_PokemonDto> personas = dao.get();

        for (Gimnasio_PokemonDto persona : personas) {
            Object[] rowData = {
                    persona.getID_GimnasioPokemon(),
                    persona.getSnombre(),
                    persona.getNcaracteristicas_espaciales(),
                    persona.getID_pueblo()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_GimnasioPokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_GimnasioPokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String idGimnasioPokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_GimnasioPokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idGimnasioPokemonStr == null || idGimnasioPokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_GimnasioPokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String snombre = JOptionPane.showInputDialog(null, "Por favor, introduce snombre:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (snombre == null || snombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún snombre.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ncaracteristicasEspacialesStr = JOptionPane.showInputDialog(null, "Por favor, introduce ncaracteristicas_espaciales:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ncaracteristicasEspacialesStr == null || ncaracteristicasEspacialesStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ncaracteristicas_espaciales.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idPueblo = JOptionPane.showInputDialog(null, "Por favor, introduce ID_pueblo:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idPueblo == null || idPueblo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_pueblo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int idGimnasioPokemon;
        int ncaracteristicasEspaciales;

        try {
            idGimnasioPokemon = Integer.parseInt(idGimnasioPokemonStr);
            ncaracteristicasEspaciales = Integer.parseInt(ncaracteristicasEspacialesStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Gimnasio_PokemonDto entrenadorExistente = dao.getById(idGimnasioPokemon);
        // Verificar si el ID_GimnasioPokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_GimnasioPokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_GimnasioPokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == idGimnasioPokemon) {
                JOptionPane.showMessageDialog(null, "El ID_GimnasioPokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(idGimnasioPokemon, snombre, ncaracteristicasEspaciales, idPueblo);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{idGimnasioPokemon, snombre, ncaracteristicasEspaciales, idPueblo});
    }

    public void testDelete(int ID_GimnasioPokemon) {
        Gimnasio_PokemonDao dao = FactoryDao.obtenerOCrear().newGimnasio_PokemonDao();
        dao.delete(ID_GimnasioPokemon);
    }

    public void testInsert(int ID_GimnasioPokemon, String snombre, int ncaracteristicasEspaciales, String ID_pueblo) {
        Gimnasio_PokemonDao dao = FactoryDao.obtenerOCrear().newGimnasio_PokemonDao();
        Gimnasio_PokemonDto nuevo = new Gimnasio_PokemonDto(ID_GimnasioPokemon, snombre, ncaracteristicasEspaciales, ID_pueblo);
        dao.insert(nuevo);
    }
}