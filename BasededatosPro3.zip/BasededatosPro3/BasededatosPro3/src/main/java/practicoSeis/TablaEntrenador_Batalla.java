package practicoSeis;

import practicoSeis.dao.Entrenador_BatallaDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Entrenador_BatallaDaoMysql;
import practicoSeis.dto.Entrenador_BatallaDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaEntrenador_Batalla extends JFrame{
    private JTable table;
    private DefaultTableModel tableModel;
    private Entrenador_BatallaDao dao = FactoryDao.obtenerOCrear().newEntrenador_BatallaDao();

    public TablaEntrenador_Batalla() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

// Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"id", "Entrenador_ID", "Batalla_ID"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Entrenador_BatallaDaoMysql dao = new Entrenador_BatallaDaoMysql();
        Lista<Entrenador_BatallaDto> personas = dao.get();

        for (Entrenador_BatallaDto persona : personas) {
            Object[] rowData = {
                    persona.getId(),
                    persona.getEntrenador_ID(),
                    persona.getBatalla_ID()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object id = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) id); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String idStr = JOptionPane.showInputDialog(null, "Por favor, introduce id:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idStr == null || idStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún id.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String entrenadorIDStr = JOptionPane.showInputDialog(null, "Por favor, introduce Entrenador_ID:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (entrenadorIDStr == null || entrenadorIDStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Entrenador_ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String batallaIDStr = JOptionPane.showInputDialog(null, "Por favor, introduce Batalla_ID:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (batallaIDStr == null || batallaIDStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Batalla_ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int id;
        int entrenadorID;
        int batallaID;

        try {
            id = Integer.parseInt(idStr);
            entrenadorID = Integer.parseInt(entrenadorIDStr);
            batallaID = Integer.parseInt(batallaIDStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Entrenador_BatallaDto entrenadorExistente = dao.getById(id);
        // Verificar si el id ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El id ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el id ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == id) {
                JOptionPane.showMessageDialog(null, "El id ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(id, entrenadorID, batallaID);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{id, entrenadorID, batallaID});
    }

    public void testDelete(int id) {
        Entrenador_BatallaDao dao = FactoryDao.obtenerOCrear().newEntrenador_BatallaDao();
        dao.delete(id);
    }

    public void testInsert(int id, int Entrenador_ID, int Batalla_ID) {
        Entrenador_BatallaDao dao = FactoryDao.obtenerOCrear().newEntrenador_BatallaDao();
        Entrenador_BatallaDto nuevo = new Entrenador_BatallaDto(id, Entrenador_ID, Batalla_ID);
        dao.insert(nuevo);
    }
}

