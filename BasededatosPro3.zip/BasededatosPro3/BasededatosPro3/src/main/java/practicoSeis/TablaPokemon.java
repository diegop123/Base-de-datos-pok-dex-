package practicoSeis;

import practicoSeis.dao.PokemonDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.PokemonDaoMysql;
import practicoSeis.dto.PokemonDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPokemon extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PokemonDao dao = FactoryDao.obtenerOCrear().newPokemonDao();

    public TablaPokemon() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_Pokemon", "Snombre", "Stipo", "Sdescripcion", "Sestado", "Habitante_ID"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        PokemonDaoMysql dao = new PokemonDaoMysql();
        Lista<PokemonDto> personas = dao.get();

        for (PokemonDto persona : personas) {
            Object[] rowData = {
                    persona.getID_Pokemon(),
                    persona.getSnombre(),
                    persona.getStipo(),
                    persona.getSdescripcion(),
                    persona.getSestado(),
                    persona.getHabitante_ID()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_Pokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_Pokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String ID_PokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_Pokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_PokemonStr == null || ID_PokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_Pokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Snombre = JOptionPane.showInputDialog(null, "Por favor, introduce Snombre:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Snombre == null || Snombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Snombre.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Stipo = JOptionPane.showInputDialog(null, "Por favor, introduce Stipo:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Stipo == null || Stipo.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Stipo.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Sdescripcion = JOptionPane.showInputDialog(null, "Por favor, introduce Sdescripcion:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Sdescripcion == null || Sdescripcion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Sdescripcion.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Sestado = JOptionPane.showInputDialog(null, "Por favor, introduce Sestado:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Sestado == null || Sestado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Sestado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Habitante_IDStr = JOptionPane.showInputDialog(null, "Por favor, introduce Habitante_ID:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Habitante_IDStr == null || Habitante_IDStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Habitante_ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int ID_Pokemon;
        int Habitante_ID;

        try {
            ID_Pokemon = Integer.parseInt(ID_PokemonStr);
            Habitante_ID = Integer.parseInt(Habitante_IDStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        PokemonDto entrenadorExistente = dao.getById(ID_Pokemon);
        // Verificar si el ID_Pokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_Pokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == ID_Pokemon) {
                JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID});
    }

    public void testDelete(int ID_Pokemon) {
        PokemonDao dao = FactoryDao.obtenerOCrear().newPokemonDao();
        dao.delete(ID_Pokemon);
    }

    public void testInsert(int ID_Pokemon, String Snombre, String Stipo, String Sdescripcion, String Sestado, int Habitante_ID) {
        PokemonDao dao = FactoryDao.obtenerOCrear().newPokemonDao();
        PokemonDto nuevo = new PokemonDto(ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID);
        dao.insert(nuevo);
    }
}
