package practicoSeis;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.TablaPersonaDao;
import practicoSeis.dao.mysql.TablaPersonaMysql;
import practicoSeis.dto.TablaPersonaDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPersonaInterfaz extends JFrame {
    private JTable tabla;
    private DefaultTableModel tablaModel;
    private static Logger logger = LogManager.getRootLogger();


    public TablaPersonaInterfaz() {
        setTitle("BD PROGRAMACION");
        setSize(1200, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Crear el modelo de la tabla con 4 columnas
        tablaModel = new DefaultTableModel(new Object[]{"id", "nombre", "alturacm", "pesokg"}, 0) {
            @Override
            // No editar las tablas, Dado que el método siempre devuelve false, ninguna celda podrá ser editada por el usuario.
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        TablaPersonaMysql dao = new TablaPersonaMysql();
        Lista<TablaPersonaDto> personas = dao.get();

        for (TablaPersonaDto persona : personas) {
            Object[] datosTabla = {
                    persona.getId(),
                    persona.getNombre(),
                    persona.getAlturacm(),
                    persona.getPesokg()
            };
            tablaModel.addRow(datosTabla);
        }


        // Crear la tabla con el modelo
        tabla = new JTable(tablaModel);
        JScrollPane scrollPane = new JScrollPane(tabla); // panel de desplazamiento
        //tabla.setEnabled(false);

        // Crear el botón para agregar filas
        JButton Insertar = new JButton("Insertar");
        Insertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("Se presiono el boton Insertar");
                crearFila();
            }
        });
        JButton editar = new JButton("Editar");
        editar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("Se presiono el boton Editar");
                actualizarFila();
            }
        });
        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logger.info("Se presiono el boton Eliminar");
                borrarFila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(Insertar);
        buttonPanel.add(editar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarFila() {
        // Obtenemos el indice de la fila seleccionada
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada >= 0) {
            Object id = tablaModel.getValueAt(filaSeleccionada, 0);

            testDelete((Integer) id); // Llamar al método estático testDelete
            tablaModel.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            logger.info("Se acaba de eliminar el registro de manera exitosa");
        }
    }

    public void actualizarFila() {
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada >= 0) {
            // Obtener los valores actuales
            Object id = tablaModel.getValueAt(filaSeleccionada, 0);
            String nombre = (String) tablaModel.getValueAt(filaSeleccionada, 1);
            int altura = (int) tablaModel.getValueAt(filaSeleccionada, 2);
            float peso = (float) tablaModel.getValueAt(filaSeleccionada, 3);

            // Mostrar diálogos de entrada para editar los valores

            String newNombre = JOptionPane.showInputDialog("Editar Nombre:", nombre);
            String newAltura = JOptionPane.showInputDialog("Editar Altura (cm):", altura);
            String newPeso = JOptionPane.showInputDialog("Editar Peso (kg):", peso);

            // Actualizar los valores en el modelo de tabla
            if (newNombre != null && newAltura != null && newPeso != null) {
                tablaModel.setValueAt(newNombre, filaSeleccionada, 1);
                tablaModel.setValueAt(Integer.parseInt(newAltura), filaSeleccionada, 2);
                tablaModel.setValueAt(Float.parseFloat(newPeso), filaSeleccionada, 3);
                testUpdate((int) id, newNombre, Integer.parseInt(newAltura), Float.parseFloat(newPeso));
            }
            logger.info("Registro actualizado de manera exitosa");
        }
    }



    public void crearFila() {
        String idStr = JOptionPane.showInputDialog(null, "Por favor, introduce tu id:", "Datos", JOptionPane.QUESTION_MESSAGE);
        if (idStr == null || idStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún id.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombre = JOptionPane.showInputDialog(null, "Por favor, introduce tu nombre:", "Datos", JOptionPane.QUESTION_MESSAGE);
        if (nombre == null || nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún nombre.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String alturacmStr = JOptionPane.showInputDialog(null, "Por favor, introduce tu Altura en cm:", "Datos", JOptionPane.QUESTION_MESSAGE);
        if (alturacmStr == null || alturacmStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún detalle sobre la altura.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String pesokgStr = JOptionPane.showInputDialog(null, "Por favor, introduce tu peso en KG:", "Datos", JOptionPane.QUESTION_MESSAGE);
        if (pesokgStr == null || pesokgStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún detalle sobre el peso.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int id;
        int alturacm;
        float pesokg;

        try {
            id = Integer.parseInt(idStr);
            alturacm = Integer.parseInt(alturacmStr);
            pesokg = Float.parseFloat(pesokgStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insertar en la base de datos
        testInsert(id, nombre, alturacm, pesokg);

        // Agregar fila a la tabla
        tablaModel.addRow(new Object[]{id, nombre, alturacm, pesokg});
        logger.info("Se acaba de agregar el registro de manera exitosa");

    }
    public void testDelete(int id) {
        TablaPersonaDao dao = FactoryDao.obtenerOCrear().newTablaPersonaDao();
        dao.delete(id);
    }

    private static void testUpdate(int id, String nombre, int alturacm, float pesokg) {
        TablaPersonaDao dao = FactoryDao.obtenerOCrear().newTablaPersonaDao();
        TablaPersonaDto persona = dao.getById(id);
        persona.setNombre(nombre);
        persona.setAlturacm(alturacm);
        persona.setPesokg(pesokg);
        dao.update(persona);
    }

    public void testInsert(int id, String nombre, int alturacm, float pesokg) {
        TablaPersonaDao dao = FactoryDao.obtenerOCrear().newTablaPersonaDao();
        TablaPersonaDto nuevo = new TablaPersonaDto(id, nombre, alturacm, pesokg);
        dao.insert(nuevo);
    }

}
