package practicoSeis;

import practicoSeis.dao.PuebloDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.PuebloDaoMysql;
import practicoSeis.dto.PuebloDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPueblo extends JFrame {


}
