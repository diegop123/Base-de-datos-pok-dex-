package practicoSeis;

import practicoSeis.dao.Equipo_PokemonDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Equipo_PokemonDaoMysql;
import practicoSeis.dto.Equipo_PokemonDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaEquipo_Pokemon extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Equipo_PokemonDao dao = FactoryDao.obtenerOCrear().newEquipo_PokemonDao();

    public TablaEquipo_Pokemon() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_equipoP", "ID_entrenador", "ID_pokemon"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Equipo_PokemonDaoMysql dao = new Equipo_PokemonDaoMysql();
        Lista<Equipo_PokemonDto> personas = dao.get();

        for (Equipo_PokemonDto persona : personas) {
            Object[] rowData = {
                    persona.getID_equipoP(),
                    persona.getID_entrenador(),
                    persona.getID_pokemon()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object idEquipoP = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) idEquipoP); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String idEquipoPStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_equipoP:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idEquipoPStr == null || idEquipoPStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_equipoP.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idEntrenadorStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_entrenador:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idEntrenadorStr == null || idEntrenadorStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_entrenador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idPokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_pokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idPokemonStr == null || idPokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_pokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int idEquipoP;
        int idEntrenador;
        int idPokemon;

        try {
            idEquipoP = Integer.parseInt(idEquipoPStr);
            idEntrenador = Integer.parseInt(idEntrenadorStr);
            idPokemon = Integer.parseInt(idPokemonStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Equipo_PokemonDto entrenadorExistente = dao.getById(idEquipoP);
        // Verificar si el ID_equipoP ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_equipoP ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_equipoP ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == idEquipoP) {
                JOptionPane.showMessageDialog(null, "El ID_equipoP ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(idEquipoP, idEntrenador, idPokemon);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{idEquipoP, idEntrenador, idPokemon});
    }

    public void testDelete(int idEquipoP) {
        Equipo_PokemonDao dao = FactoryDao.obtenerOCrear().newEquipo_PokemonDao();
        dao.delete(idEquipoP);
    }

    public void testInsert(int ID_equipoP, int ID_entrenador, int ID_pokemon) {
        Equipo_PokemonDao dao = FactoryDao.obtenerOCrear().newEquipo_PokemonDao();
        Equipo_PokemonDto nuevo = new Equipo_PokemonDto(ID_equipoP, ID_entrenador, ID_pokemon);
        dao.insert(nuevo);
    }
}

