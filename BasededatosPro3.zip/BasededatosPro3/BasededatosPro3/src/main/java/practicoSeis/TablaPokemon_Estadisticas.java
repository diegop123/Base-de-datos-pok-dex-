package practicoSeis;

import practicoSeis.dao.Pokemon_EstadisticasDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Pokemon_EstadisticasDaoMysql;
import practicoSeis.dto.Pokemon_EstadisticasDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPokemon_Estadisticas extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Pokemon_EstadisticasDao dao = FactoryDao.obtenerOCrear().newPokemon_EstadisticasDao();

    public TablaPokemon_Estadisticas() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_Pokemon", "Nsalud", "Nataque", "Ndefensa", "Nvelocidad", "Sestadisticas"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Pokemon_EstadisticasDaoMysql dao = new Pokemon_EstadisticasDaoMysql();
        Lista<Pokemon_EstadisticasDto> personas = dao.get();

        for (Pokemon_EstadisticasDto persona : personas) {
            Object[] rowData = {
                    persona.getID_Pokemon(),
                    persona.getNsalud(),
                    persona.getNataque(),
                    persona.getNdefensa(),
                    persona.getNvelocidad(),
                    persona.getSestadisticas()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_Pokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_Pokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String ID_PokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_Pokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_PokemonStr == null || ID_PokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_Pokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String NsaludStr = JOptionPane.showInputDialog(null, "Por favor, introduce Nsalud:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (NsaludStr == null || NsaludStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Nsalud.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String NataqueStr = JOptionPane.showInputDialog(null, "Por favor, introduce Nataque:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (NataqueStr == null || NataqueStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Nataque.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String NdefensaStr = JOptionPane.showInputDialog(null, "Por favor, introduce Ndefensa:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (NdefensaStr == null || NdefensaStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Ndefensa.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String NvelocidadStr = JOptionPane.showInputDialog(null, "Por favor, introduce Nvelocidad:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (NvelocidadStr == null || NvelocidadStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Nvelocidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Sestadisticas = JOptionPane.showInputDialog(null, "Por favor, introduce Sestadisticas:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Sestadisticas == null || Sestadisticas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna Sestadisticas.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int ID_Pokemon;
        int Nsalud;
        int Nataque;
        int Ndefensa;
        int Nvelocidad;

        try {
            ID_Pokemon = Integer.parseInt(ID_PokemonStr);
            Nsalud = Integer.parseInt(NsaludStr);
            Nataque = Integer.parseInt(NataqueStr);
            Ndefensa = Integer.parseInt(NdefensaStr);
            Nvelocidad = Integer.parseInt(NvelocidadStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Pokemon_EstadisticasDto entrenadorExistente = dao.getById(ID_Pokemon);
        // Verificar si el ID_Pokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_Pokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == ID_Pokemon) {
                JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas});
    }

    public void testDelete(int ID_Pokemon) {
        Pokemon_EstadisticasDao dao = FactoryDao.obtenerOCrear().newPokemon_EstadisticasDao();
        dao.delete(ID_Pokemon);
    }

    public void testInsert(int ID_Pokemon, int Nsalud, int Nataque, int Ndefensa, int Nvelocidad, String Sestadisticas) {
        Pokemon_EstadisticasDao dao = FactoryDao.obtenerOCrear().newPokemon_EstadisticasDao();
        Pokemon_EstadisticasDto nuevo = new Pokemon_EstadisticasDto(ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas);
        dao.insert(nuevo);
    }
}
