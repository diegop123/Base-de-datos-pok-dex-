package practicoSeis;

import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.PersonaDao;
import practicoSeis.dao.mysql.PersonaDaoMysql;
import practicoSeis.dto.PersonaDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaBatalla extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersonaDao dao = FactoryDao.obtenerOCrear().newPersonaDao();

    public TablaBatalla(){
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);


// Crear el modelo de la tabla con 4 columnas
        tableModel = new DefaultTableModel(new Object[]{"nID_Batalla", "nTurnosFinalizados", "sEstado", "sGanador", "nResultado",
                "sEventos", "nDuracion", "ID_Entrenador_Batalla", "ID_Entrenador"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        PersonaDaoMysql dao = new PersonaDaoMysql();
        Lista<PersonaDto> personas = dao.get();

        for (PersonaDto persona : personas) {
            Object[] rowData = {
                    persona.getnID_Batalla(),
                    persona.getnTurnosFinalizados(),
                    persona.getsEstado(),
                    persona.getsGanador(),
                    persona.getnResultado(),
                    persona.getsEventos(),
                    persona.getnDuracion(),
                    persona.getID_Entrenador_Batalla(),
                    persona.getID_Entrenador(),

            };
            tableModel.addRow(rowData);
        }


        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar= new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });
        JButton editar = new JButton("Editar");
        editar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarfila();
            }
        });
        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        //buttonPanel.add(editar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);

    }


    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_Batalla = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_Batalla); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void actualizarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            // Obtener los valores actuales
            Object ID_Batalla = tableModel.getValueAt(selectedRow, 0);
            int turnosFinalizados = (int) tableModel.getValueAt(selectedRow, 2);
            String estado = (String) tableModel.getValueAt(selectedRow, 1);
            String ganador = (String) tableModel.getValueAt(selectedRow, 1);
            String resultado = (String) tableModel.getValueAt(selectedRow, 1);
            String eventos = (String) tableModel.getValueAt(selectedRow, 1);
            int duracion = (int) tableModel.getValueAt(selectedRow, 3);
            int idEntrenadorBatalla = (int) tableModel.getValueAt(selectedRow, 3);
            int idEntrenador = (int) tableModel.getValueAt(selectedRow, 3);


            // Mostrar diálogos de entrada para editar los valores

            String newTurnosFinalizados = JOptionPane.showInputDialog("Editar  nTurnosFinalizados:", turnosFinalizados);
            String newEstado = JOptionPane.showInputDialog("Editar sEstado:", estado);
            String newGanador = JOptionPane.showInputDialog("Editar sGanador:", ganador);
            String newResultado = JOptionPane.showInputDialog("Editar nResultado:", resultado);
            String newEvento = JOptionPane.showInputDialog("Editar sEventos:", eventos);
            String newDuracion = JOptionPane.showInputDialog("Editar nDuracion:", duracion);
            String newIdEntrenadorBatalla = JOptionPane.showInputDialog("Editar sIdEntrenadorBatalla:", idEntrenadorBatalla);
            String newIdEntrenador = JOptionPane.showInputDialog("Editar sIdEntrenador:", idEntrenador);

            // Actualizar los valores en el modelo de tabla
            if (newEstado != null && newTurnosFinalizados != null && newDuracion != null) {
                tableModel.setValueAt(Integer.parseInt(newTurnosFinalizados), selectedRow, 2);
                tableModel.setValueAt(newEstado, selectedRow, 1);
                tableModel.setValueAt(newGanador, selectedRow, 1);
                tableModel.setValueAt(newResultado, selectedRow, 1);
                tableModel.setValueAt(newEvento, selectedRow, 1);
                tableModel.setValueAt(Integer.parseInt(newDuracion), selectedRow, 3);
                tableModel.setValueAt(Integer.parseInt(newIdEntrenadorBatalla), selectedRow, 3);
                tableModel.setValueAt(Integer.parseInt(newIdEntrenador), selectedRow, 3);
                testUpdate((int) ID_Batalla, Integer.parseInt(newTurnosFinalizados), newEstado, newGanador, newResultado,
                        newEvento, Integer.parseInt(newDuracion), Integer.parseInt(newIdEntrenadorBatalla), Integer.parseInt(newIdEntrenador) );
            }
        }
    }



    public void crearFILA() {
        String IdBatallaStr = JOptionPane.showInputDialog(null, "Por favor, introduce idBatalla:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (IdBatallaStr == null || IdBatallaStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún id.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String turnosFinalizadosStr = JOptionPane.showInputDialog(null, "Por favor, introduce turnosFinalizados:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (turnosFinalizadosStr == null || turnosFinalizadosStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún turnosFinalizados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sEstado = JOptionPane.showInputDialog(null, "Por favor, introduce sEstado:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sEstado == null || sEstado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún sEstado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sGanador = JOptionPane.showInputDialog(null, "Por favor, introduce sGanador:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sGanador == null || sGanador.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún sGanador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nResultado = JOptionPane.showInputDialog(null, "Por favor, introduce nResultado:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (nResultado == null || nResultado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún nResultado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sEventos = JOptionPane.showInputDialog(null, "Por favor, introduce sEventos:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sEventos == null || sEventos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún sEventos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String duracionStr = JOptionPane.showInputDialog(null, "Por favor, introduce nDuracion:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (duracionStr == null || duracionStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún nDuracion.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idEntrenadorBatallaStr = JOptionPane.showInputDialog(null, "Por favor, introduce IDEntrenadorBatalla:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idEntrenadorBatallaStr == null || idEntrenadorBatallaStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún IDEntrenadorBatalla.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String idEntrenadorStr = JOptionPane.showInputDialog(null, "Por favor, introduce IDEntrenador:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idEntrenadorStr == null || idEntrenadorStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún IDEntrenador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        // Convertir las entradas a los tipos adecuados
        int idBatalla;
        int turnosFinalizados;
        int duracion;
        int idEntrenadorBatalla;
        int idEntrenador;

        try {
            idBatalla = Integer.parseInt(IdBatallaStr);
            turnosFinalizados = Integer.parseInt(turnosFinalizadosStr);
            duracion = Integer.parseInt(duracionStr);
            idEntrenadorBatalla = Integer.parseInt(idEntrenadorBatallaStr);
            idEntrenador = Integer.parseInt(idEntrenadorStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        PersonaDto personaExistente = dao.getById(idBatalla);

        // Verificar si el ID ya existe en la base de datos
        if (personaExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == idBatalla) {
                JOptionPane.showMessageDialog(null, "El ID ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(idBatalla, turnosFinalizados, sEstado, sGanador, nResultado, sEventos, duracion, idEntrenadorBatalla, idEntrenador );

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{idBatalla, turnosFinalizados, sEstado, sGanador, nResultado, sEventos, duracion, idEntrenadorBatalla, idEntrenador});



    }


    public void testDelete(int nID_Batalla) {
        PersonaDao dao = FactoryDao.obtenerOCrear().newPersonaDao();
        dao.delete(nID_Batalla);
    }

    private static void testUpdate(int nID_Batalla, int nTurnosFinalizados,String sEstado,String sGanador,
                                   String sEventos, String nResultado, int nDuracion, int ID_Entrenador_Batalla, int ID_Entrenador) {
        PersonaDao dao = FactoryDao.obtenerOCrear().newPersonaDao();
        PersonaDto persona = dao.getById(nID_Batalla);
        persona.setnTurnosFinalizados(nTurnosFinalizados);
        persona.setsEstado(sEstado);
        persona.setsGanador(sGanador);
        persona.setsEventos(sEventos);
        persona.setnResultado(nResultado);
        persona.setnDuracion(nDuracion);
        persona.setID_Entrenador_Batalla(ID_Entrenador_Batalla);
        persona.setID_Entrenador(ID_Entrenador);
        dao.update(persona);
    }

    public void testInsert(int nID_Batalla, int nTurnosFinalizados,String sEstado,String sGanador,
                           String sEventos, String nResultado, int nDuracion, int ID_Entrenador_Batalla, int ID_Entrenador) {
        PersonaDao dao = FactoryDao.obtenerOCrear().newPersonaDao();
        PersonaDto nuevo = new PersonaDto(nID_Batalla, nTurnosFinalizados, sEstado, sGanador,
                sEventos,  nResultado,  nDuracion,  ID_Entrenador_Batalla,  ID_Entrenador);
        dao.insert(nuevo);
    }
}
