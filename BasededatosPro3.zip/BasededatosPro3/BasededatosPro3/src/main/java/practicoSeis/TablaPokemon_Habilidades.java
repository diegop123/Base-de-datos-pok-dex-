package practicoSeis;

import practicoSeis.dao.Pokemon_HabilidadesDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Pokemon_DebilidadesDaoMysql;
import practicoSeis.dao.mysql.Pokemon_HabilidadesDaoMysql;
import practicoSeis.dto.Pokemon_HabilidadesDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaPokemon_Habilidades extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Pokemon_HabilidadesDao dao = FactoryDao.obtenerOCrear().newPokemon_HabilidadesDao();

    public TablaPokemon_Habilidades() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_Pokemon", "Habilidades"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Pokemon_HabilidadesDaoMysql dao = new Pokemon_HabilidadesDaoMysql();
        Lista<Pokemon_HabilidadesDto> personas = dao.get();

        for (Pokemon_HabilidadesDto persona : personas) {
            Object[] rowData = {
                    persona.getID_Pokemon(),
                    persona.getHabilidades()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_Pokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_Pokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String ID_PokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_Pokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_PokemonStr == null || ID_PokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_Pokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Habilidades = JOptionPane.showInputDialog(null, "Por favor, introduce Habilidades:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Habilidades == null || Habilidades.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna Habilidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int ID_Pokemon;

        try {
            ID_Pokemon = Integer.parseInt(ID_PokemonStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Pokemon_HabilidadesDto entrenadorExistente = dao.getById(ID_Pokemon);
        // Verificar si el ID_Pokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_Pokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == ID_Pokemon) {
                JOptionPane.showMessageDialog(null, "El ID_Pokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(ID_Pokemon, Habilidades);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{ID_Pokemon, Habilidades});
    }

    public void testDelete(int ID_Pokemon) {
        Pokemon_HabilidadesDao dao = FactoryDao.obtenerOCrear().newPokemon_HabilidadesDao();
        dao.delete(ID_Pokemon);
    }

    public void testInsert(int ID_Pokemon, String Habilidades) {
        Pokemon_HabilidadesDao dao = FactoryDao.obtenerOCrear().newPokemon_HabilidadesDao();
        Pokemon_HabilidadesDto nuevo = new Pokemon_HabilidadesDto(ID_Pokemon, Habilidades);
        dao.insert(nuevo);
    }
}
