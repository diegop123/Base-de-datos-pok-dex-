package practicoSeis;

public class TablaRegion {
}
