package practicoSeis;

import practicoSeis.dao.GimnasioPokemon_DesafioDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.GimnasioPokemon_DesafioDaoMysql;
import practicoSeis.dto.GimnasioPokemon_DesafioDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaGimnasioPokemon_Desafio extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private GimnasioPokemon_DesafioDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_DesafioDao();

    public TablaGimnasioPokemon_Desafio() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_GimnacioPokemon", "desafio"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        GimnasioPokemon_DesafioDaoMysql dao = new GimnasioPokemon_DesafioDaoMysql();
        Lista<GimnasioPokemon_DesafioDto> personas = dao.get();

        for (GimnasioPokemon_DesafioDto persona : personas) {
            Object[] rowData = {
                    persona.getID_GimnacioPokemon(),
                    persona.getDesafio()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_GimnacioPokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_GimnacioPokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String idGimnacioPokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_GimnacioPokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (idGimnacioPokemonStr == null || idGimnacioPokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_GimnacioPokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String desafio = JOptionPane.showInputDialog(null, "Por favor, introduce desafio:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (desafio == null || desafio.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún desafio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int idGimnacioPokemon;

        try {
            idGimnacioPokemon = Integer.parseInt(idGimnacioPokemonStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        GimnasioPokemon_DesafioDto entrenadorExistente = dao.getById(idGimnacioPokemon);
        // Verificar si el ID_GimnacioPokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_GimnacioPokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_GimnacioPokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == idGimnacioPokemon) {
                JOptionPane.showMessageDialog(null, "El ID_GimnacioPokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(idGimnacioPokemon, desafio);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{idGimnacioPokemon, desafio});
    }

    public void testDelete(int ID_GimnacioPokemon) {
        GimnasioPokemon_DesafioDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_DesafioDao();
        dao.delete(ID_GimnacioPokemon);
    }

    public void testInsert(int ID_GimnacioPokemon, String desafio) {
        GimnasioPokemon_DesafioDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_DesafioDao();
        GimnasioPokemon_DesafioDto nuevo = new GimnasioPokemon_DesafioDto(ID_GimnacioPokemon, desafio);
        dao.insert(nuevo);
    }
}
