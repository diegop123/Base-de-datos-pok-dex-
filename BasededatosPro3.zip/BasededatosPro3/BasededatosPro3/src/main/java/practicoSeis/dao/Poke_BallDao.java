package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Poke_BallDto;

public abstract class Poke_BallDao implements IDao<Poke_BallDto, Integer> {
}
