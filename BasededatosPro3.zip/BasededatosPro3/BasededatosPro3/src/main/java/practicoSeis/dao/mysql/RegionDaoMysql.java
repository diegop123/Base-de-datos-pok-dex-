package practicoSeis.dao.mysql;

public class RegionDaoMysql {
}
