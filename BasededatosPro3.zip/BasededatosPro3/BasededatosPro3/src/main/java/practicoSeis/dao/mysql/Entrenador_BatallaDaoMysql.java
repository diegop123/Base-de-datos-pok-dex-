package practicoSeis.dao.mysql;

import practicoSeis.dao.Entrenador_BatallaDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Entrenador_BatallaDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Entrenador_BatallaDaoMysql extends Entrenador_BatallaDao {
    public Lista<Entrenador_BatallaDto> get() {
        Lista<Entrenador_BatallaDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT id, Entrenador_ID, Batalla_ID FROM Entrenador_Batalla";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("id");
                int Entrenador_ID = rs.getInt("Entrenador_ID");
                int Batalla_ID = rs.getInt("Batalla_ID");

                Entrenador_BatallaDto dto = new Entrenador_BatallaDto(id, Entrenador_ID, Batalla_ID);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Entrenador_BatallaDto insert(Entrenador_BatallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO Entrenador_Batalla (id, Entrenador_ID, Batalla_ID) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getId());
            stmt.setInt(2, obj.getEntrenador_ID());
            stmt.setInt(3, obj.getBatalla_ID());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Entrenador_BatallaDto update(Entrenador_BatallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE Entrenador_Batalla SET Entrenador_ID = ?, Batalla_ID = ? WHERE id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getEntrenador_ID());
            stmt.setInt(2, obj.getBatalla_ID());
            stmt.setInt(3, obj.getId());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer id) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM Entrenador_Batalla WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Entrenador_BatallaDto getById(Integer id) {
        Entrenador_BatallaDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT id, Entrenador_ID, Batalla_ID FROM Entrenador_Batalla WHERE id = " + id;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objId = rs.getInt("id");
            int Entrenador_ID = rs.getInt("Entrenador_ID");
            int Batalla_ID = rs.getInt("Batalla_ID");

            resultado = new Entrenador_BatallaDto(objId, Entrenador_ID, Batalla_ID);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}

