package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Lider_GymDto;

public abstract class Lider_GymDao implements IDao<Lider_GymDto, Integer> {
}
