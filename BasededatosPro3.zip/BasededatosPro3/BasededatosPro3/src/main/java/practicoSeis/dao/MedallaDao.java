package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.MedallaDto;

public abstract class MedallaDao implements IDao<MedallaDto, Integer> {
}
