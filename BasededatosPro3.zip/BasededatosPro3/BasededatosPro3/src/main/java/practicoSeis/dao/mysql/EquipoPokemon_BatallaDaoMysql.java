package practicoSeis.dao.mysql;


import practicoSeis.dao.EquipoPokemon_BatallaDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.EquipoPokemon_BatallaDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class EquipoPokemon_BatallaDaoMysql extends EquipoPokemon_BatallaDao {
    public Lista<EquipoPokemon_BatallaDto> get() {
        Lista<EquipoPokemon_BatallaDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_EquipoPokemon, ID_Batalla FROM equipopokemon_batalla";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int idEquipoPokemon = rs.getInt("ID_EquipoPokemon");
                int idBatalla = rs.getInt("ID_Batalla");

                EquipoPokemon_BatallaDto dto = new EquipoPokemon_BatallaDto(idEquipoPokemon, idBatalla);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public EquipoPokemon_BatallaDto insert(EquipoPokemon_BatallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO equipopokemon_batalla (ID_EquipoPokemon, ID_Batalla) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_EquipoPokemon());
            stmt.setInt(2, obj.getID_Batalla());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public EquipoPokemon_BatallaDto update(EquipoPokemon_BatallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE equipopokemon_batalla SET ID_Batalla = ? WHERE ID_EquipoPokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Batalla());
            stmt.setInt(2, obj.getID_EquipoPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer idEquipoPokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM equipopokemon_batalla WHERE ID_EquipoPokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idEquipoPokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public EquipoPokemon_BatallaDto getById(Integer idEquipoPokemon) {
        EquipoPokemon_BatallaDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_EquipoPokemon, ID_Batalla FROM equipopokemon_batalla WHERE ID_EquipoPokemon = " + idEquipoPokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objIdEquipoPokemon = rs.getInt("ID_EquipoPokemon");
            int idBatalla = rs.getInt("ID_Batalla");

            resultado = new EquipoPokemon_BatallaDto(objIdEquipoPokemon, idBatalla);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
