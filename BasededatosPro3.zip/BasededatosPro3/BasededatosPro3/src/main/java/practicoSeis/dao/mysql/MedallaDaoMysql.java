package practicoSeis.dao.mysql;


import practicoSeis.dao.MedallaDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.MedallaDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class MedallaDaoMysql extends MedallaDao {
    public Lista<MedallaDto> get() {
        Lista<MedallaDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon FROM medalla";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int Registro = rs.getInt("Registro");
                String Nombre = rs.getString("Nombre");
                String Requisitos = rs.getString("Requisitos");
                String diseño = rs.getString("diseño");
                String historia = rs.getString("historia");
                String significado = rs.getString("significado");
                int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");

                MedallaDto dto = new MedallaDto(Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public MedallaDto insert(MedallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO medalla (Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getRegistro());
            stmt.setString(2, obj.getNombre());
            stmt.setString(3, obj.getRequisitos());
            stmt.setString(4, obj.getDiseño());
            stmt.setString(5, obj.getHistoria());
            stmt.setString(6, obj.getSignificado());
            stmt.setInt(7, obj.getID_GimnacioPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public MedallaDto update(MedallaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE medalla SET Nombre = ?, Requisitos = ?, diseño = ?, historia = ?, significado = ?, ID_GimnacioPokemon = ? WHERE Registro = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getNombre());
            stmt.setString(2, obj.getRequisitos());
            stmt.setString(3, obj.getDiseño());
            stmt.setString(4, obj.getHistoria());
            stmt.setString(5, obj.getSignificado());
            stmt.setInt(6, obj.getID_GimnacioPokemon());
            stmt.setInt(7, obj.getRegistro());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer Registro) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM medalla WHERE Registro = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, Registro);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public MedallaDto getById(Integer Registro) {
        MedallaDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT Registro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon FROM medalla WHERE Registro = " + Registro;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objRegistro = rs.getInt("Registro");
            String Nombre = rs.getString("Nombre");
            String Requisitos = rs.getString("Requisitos");
            String diseño = rs.getString("diseño");
            String historia = rs.getString("historia");
            String significado = rs.getString("significado");
            int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");

            resultado = new MedallaDto(objRegistro, Nombre, Requisitos, diseño, historia, significado, ID_GimnacioPokemon);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
