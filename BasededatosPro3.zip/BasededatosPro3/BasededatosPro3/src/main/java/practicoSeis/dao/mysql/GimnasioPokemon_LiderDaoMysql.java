package practicoSeis.dao.mysql;

import practicoSeis.dao.GimnasioPokemon_LiderDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.GimnasioPokemon_LiderDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class GimnasioPokemon_LiderDaoMysql extends GimnasioPokemon_LiderDao {
    public Lista<GimnasioPokemon_LiderDto> get() {
        Lista<GimnasioPokemon_LiderDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, Pokemon_del_lider FROM gimnasio_pokemon_pokemon_de_lider";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");
                String Pokemon_del_lider = rs.getString("Pokemon_del_lider");

                GimnasioPokemon_LiderDto dto = new GimnasioPokemon_LiderDto(ID_GimnacioPokemon, Pokemon_del_lider);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public GimnasioPokemon_LiderDto insert(GimnasioPokemon_LiderDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO gimnasio_pokemon_pokemon_de_lider (ID_GimnacioPokemon, Pokemon_del_lider) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_GimnacioPokemon());
            stmt.setString(2, obj.getPokemon_del_lider());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public GimnasioPokemon_LiderDto update(GimnasioPokemon_LiderDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE gimnasio_pokemon_pokemon_de_lider SET Pokemon_del_lider = ? WHERE ID_GimnacioPokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getPokemon_del_lider());
            stmt.setInt(2, obj.getID_GimnacioPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_GimnacioPokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM gimnasio_pokemon_pokemon_de_lider WHERE ID_GimnacioPokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_GimnacioPokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public GimnasioPokemon_LiderDto getById(Integer ID_GimnacioPokemon) {
        GimnasioPokemon_LiderDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, Pokemon_del_lider FROM gimnasio_pokemon_pokemon_de_lider WHERE ID_GimnacioPokemon = " + ID_GimnacioPokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");
            String Pokemon_del_lider = rs.getString("Pokemon_del_lider");

            resultado = new GimnasioPokemon_LiderDto(objID_GimnacioPokemon, Pokemon_del_lider);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
