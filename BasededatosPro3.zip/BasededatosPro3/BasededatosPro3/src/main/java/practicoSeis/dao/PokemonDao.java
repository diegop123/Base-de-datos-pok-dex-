package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.PokemonDto;

public abstract class PokemonDao implements IDao<PokemonDto, Integer> {
}
