package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.PuebloDto;

public abstract class PuebloDao implements IDao<PuebloDto, Integer> {
}
