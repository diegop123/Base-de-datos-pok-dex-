package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Pokemon_FortalezasDto;

public abstract class Pokemon_FortalezasDao implements IDao<Pokemon_FortalezasDto, Integer> {
}
