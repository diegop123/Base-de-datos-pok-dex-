package practicoSeis.dao.mysql;

import practicoSeis.dao.Pokemon_HabilidadesDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Pokemon_HabilidadesDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Pokemon_HabilidadesDaoMysql extends Pokemon_HabilidadesDao {
    public Lista<Pokemon_HabilidadesDto> get() {
        Lista<Pokemon_HabilidadesDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Habilidades FROM pokemon_habilidades";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Pokemon = rs.getInt("ID_Pokemon");
                String Habilidades = rs.getString("Habilidades");

                Pokemon_HabilidadesDto dto = new Pokemon_HabilidadesDto(ID_Pokemon, Habilidades);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Pokemon_HabilidadesDto insert(Pokemon_HabilidadesDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokemon_habilidades (ID_Pokemon, Habilidades) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Pokemon());
            stmt.setString(2, obj.getHabilidades());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Pokemon_HabilidadesDto update(Pokemon_HabilidadesDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokemon_habilidades SET Habilidades = ? WHERE ID_Pokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getHabilidades());
            stmt.setInt(2, obj.getID_Pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Pokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM pokemon_habilidades WHERE ID_Pokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Pokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Pokemon_HabilidadesDto getById(Integer ID_Pokemon) {
        Pokemon_HabilidadesDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Habilidades FROM pokemon_habilidades WHERE ID_Pokemon = " + ID_Pokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Pokemon = rs.getInt("ID_Pokemon");
            String Habilidades = rs.getString("Habilidades");

            resultado = new Pokemon_HabilidadesDto(objID_Pokemon, Habilidades);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
