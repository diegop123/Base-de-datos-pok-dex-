package practicoSeis.dao.conexion;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private Connection conn; // Tiene una conexion en SQL
    /**
     * Patron Simpletor me asegura que solamente hay un objeto de ese tipo,
     * que no habra nunca otro objeto de ese tipo
     */
    private static Conexion instancia = null;
    private static Logger logger = LogManager.getRootLogger();



    public static Conexion obtenerOCrear() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }

    private Conexion() { // Nadie puede construir este tipo
        conn = null;
    }

    // Aca estamos conectando con la BD
    public Connection conectar() {
        try {
            // Si no es nula y es valida
            if (conn != null && conn.isValid(10)) {
                return conn;
            }
            //Si no es asi, volvemos a hacerlo
            String servidor = "localhost";
            String bd = "pokebatallas";
            String usuario = "root";
            String clave = "F@lcon9988";

            String strConexion = "jdbc:mysql://" + servidor + "/" +
                    bd + "?" +
                    "user=" + usuario +
                    "&password=" + clave;

            conn = DriverManager.getConnection(strConexion);
        } catch (SQLException ex) {
            // handle any errors
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            conn = null;
        }
        return conn;
    }

    public void desconectar() throws SQLException {
        // Si la conexion es nula o si la conexion ya esta cerrada
        if (conn == null || conn.isClosed()) {
            conn = null;
            return;
        }

        conn.close();
    }
}
