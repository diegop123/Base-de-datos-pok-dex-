package practicoSeis.dao.mysql;

import practicoSeis.dao.Equipo_PokemonDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Equipo_PokemonDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Equipo_PokemonDaoMysql extends Equipo_PokemonDao {
    public Lista<Equipo_PokemonDto> get() {
        Lista<Equipo_PokemonDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_equipoP, ID_entrenador, ID_pokemon FROM equipo_pokemon";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int idEquipoP = rs.getInt("ID_equipoP");
                int idEntrenador = rs.getInt("ID_entrenador");
                int idPokemon = rs.getInt("ID_pokemon");

                Equipo_PokemonDto dto = new Equipo_PokemonDto(idEquipoP, idEntrenador, idPokemon);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Equipo_PokemonDto insert(Equipo_PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO equipo_pokemon (ID_equipoP, ID_entrenador, ID_pokemon) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_equipoP());
            stmt.setInt(2, obj.getID_entrenador());
            stmt.setInt(3, obj.getID_pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Equipo_PokemonDto update(Equipo_PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE equipo_pokemon SET ID_entrenador = ?, ID_pokemon = ? WHERE ID_equipoP = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_entrenador());
            stmt.setInt(2, obj.getID_pokemon());
            stmt.setInt(3, obj.getID_equipoP());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer idEquipoP) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM equipo_pokemon WHERE ID_equipoP = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idEquipoP);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Equipo_PokemonDto getById(Integer idEquipoP) {
        Equipo_PokemonDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_equipoP, ID_entrenador, ID_pokemon FROM equipo_pokemon WHERE ID_equipoP = " + idEquipoP;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objIdEquipoP = rs.getInt("ID_equipoP");
            int idEntrenador = rs.getInt("ID_entrenador");
            int idPokemon = rs.getInt("ID_pokemon");

            resultado = new Equipo_PokemonDto(objIdEquipoP, idEntrenador, idPokemon);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}

