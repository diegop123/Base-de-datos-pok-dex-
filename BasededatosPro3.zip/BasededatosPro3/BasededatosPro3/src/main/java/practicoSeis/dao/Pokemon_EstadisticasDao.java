package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Pokemon_EstadisticasDto;

public abstract class Pokemon_EstadisticasDao implements IDao<Pokemon_EstadisticasDto, Integer> {
}
