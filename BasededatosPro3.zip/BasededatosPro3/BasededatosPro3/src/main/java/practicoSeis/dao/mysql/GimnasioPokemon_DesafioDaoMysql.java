package practicoSeis.dao.mysql;

import practicoSeis.dao.GimnasioPokemon_DesafioDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.GimnasioPokemon_DesafioDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class GimnasioPokemon_DesafioDaoMysql extends GimnasioPokemon_DesafioDao {
    public Lista<GimnasioPokemon_DesafioDto> get() {
        Lista<GimnasioPokemon_DesafioDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, desafio FROM gimnasio_pokemon_desafio";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");
                String desafio = rs.getString("desafio");

                GimnasioPokemon_DesafioDto dto = new GimnasioPokemon_DesafioDto(ID_GimnacioPokemon, desafio);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public GimnasioPokemon_DesafioDto insert(GimnasioPokemon_DesafioDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO gimnasio_pokemon_desafio (ID_GimnacioPokemon, desafio) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_GimnacioPokemon());
            stmt.setString(2, obj.getDesafio());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public GimnasioPokemon_DesafioDto update(GimnasioPokemon_DesafioDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE gimnasio_pokemon_desafio SET desafio = ? WHERE ID_GimnacioPokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getDesafio());
            stmt.setInt(2, obj.getID_GimnacioPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_GimnacioPokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM gimnasio_pokemon_desafio WHERE ID_GimnacioPokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_GimnacioPokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public GimnasioPokemon_DesafioDto getById(Integer ID_GimnacioPokemon) {
        GimnasioPokemon_DesafioDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, desafio FROM gimnasio_pokemon_desafio WHERE ID_GimnacioPokemon = " + ID_GimnacioPokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");
            String desafio = rs.getString("desafio");

            resultado = new GimnasioPokemon_DesafioDto(objID_GimnacioPokemon, desafio);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
