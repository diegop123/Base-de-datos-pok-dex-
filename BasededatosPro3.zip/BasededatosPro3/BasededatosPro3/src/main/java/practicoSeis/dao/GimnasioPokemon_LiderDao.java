package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.GimnasioPokemon_LiderDto;

public abstract class GimnasioPokemon_LiderDao implements IDao<GimnasioPokemon_LiderDto, Integer> {
}

