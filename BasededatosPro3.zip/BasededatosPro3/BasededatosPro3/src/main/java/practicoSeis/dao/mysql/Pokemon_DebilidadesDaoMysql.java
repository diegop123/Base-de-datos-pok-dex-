package practicoSeis.dao.mysql;

import practicoSeis.dao.Pokemon_DebilidadesDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Pokemon_DebilidadesDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Pokemon_DebilidadesDaoMysql extends Pokemon_DebilidadesDao {
    public Lista<Pokemon_DebilidadesDto> get() {
        Lista<Pokemon_DebilidadesDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, nDebilidades FROM pokemon_debilidades";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Pokemon = rs.getInt("ID_Pokemon");
                int nDebilidades = rs.getInt("nDebilidades");

                Pokemon_DebilidadesDto dto = new Pokemon_DebilidadesDto(ID_Pokemon, nDebilidades);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Pokemon_DebilidadesDto insert(Pokemon_DebilidadesDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokemon_debilidades (ID_Pokemon, nDebilidades) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Pokemon());
            stmt.setInt(2, obj.getnDebilidades());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Pokemon_DebilidadesDto update(Pokemon_DebilidadesDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokemon_debilidades SET nDebilidades = ? WHERE ID_Pokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getnDebilidades());
            stmt.setInt(2, obj.getID_Pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Pokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM pokemon_debilidades WHERE ID_Pokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Pokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Pokemon_DebilidadesDto getById(Integer ID_Pokemon) {
        Pokemon_DebilidadesDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, nDebilidades FROM pokemon_debilidades WHERE ID_Pokemon = " + ID_Pokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Pokemon = rs.getInt("ID_Pokemon");
            int nDebilidades = rs.getInt("nDebilidades");

            resultado = new Pokemon_DebilidadesDto(objID_Pokemon, nDebilidades);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
