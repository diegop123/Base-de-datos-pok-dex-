package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.PersonaDto;

public abstract class PersonaDao implements IDao<PersonaDto,Integer> {

    //public abstract void convertirNombreAMayusculas();
}
