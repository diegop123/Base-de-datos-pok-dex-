package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.TablaPersonaDto;

public abstract class TablaPersonaDao implements IDao<TablaPersonaDto,Integer> {

    //public abstract void convertirNombreAMayusculas();
}
