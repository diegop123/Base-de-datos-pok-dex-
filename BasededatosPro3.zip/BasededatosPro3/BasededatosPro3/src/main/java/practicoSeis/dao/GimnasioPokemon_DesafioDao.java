package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.GimnasioPokemon_DesafioDto;

public abstract class GimnasioPokemon_DesafioDao implements IDao<GimnasioPokemon_DesafioDto, Integer> {
}
