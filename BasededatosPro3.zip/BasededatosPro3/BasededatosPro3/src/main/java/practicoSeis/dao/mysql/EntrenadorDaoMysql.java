package practicoSeis.dao.mysql;

import practicoSeis.dao.EntrenadorDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.EntrenadorDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class EntrenadorDaoMysql extends EntrenadorDao {
    public Lista<EntrenadorDto> get() {
        Lista<EntrenadorDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT nEXP, sestrategia, shistoria, Habitante_ID FROM entrenador";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int nEXP = rs.getInt("nEXP");
                String sestrategia = rs.getString("sestrategia");
                String shistoria = rs.getString("shistoria");
                int Habitante_ID = rs.getInt("Habitante_ID");

                EntrenadorDto dto = new EntrenadorDto(nEXP, sestrategia, shistoria, Habitante_ID);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public EntrenadorDto insert(EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO entrenador (nEXP, sestrategia, shistoria, Habitante_ID) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getnEXP());
            stmt.setString(2, obj.getSestrategia());
            stmt.setString(3, obj.getShistoria());
            stmt.setInt(4, obj.getHabitante_ID());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public EntrenadorDto update(EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE entrenador SET sestrategia = ?, shistoria = ?, Habitante_ID = ? WHERE nEXP = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getSestrategia());
            stmt.setString(2, obj.getShistoria());
            stmt.setInt(3, obj.getHabitante_ID());
            stmt.setInt(4, obj.getnEXP());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer nEXP) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM entrenador WHERE nEXP = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, nEXP);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public EntrenadorDto getById(Integer nEXP) {
        EntrenadorDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT nEXP, sestrategia, shistoria, Habitante_ID FROM entrenador WHERE nEXP = " + nEXP;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objnEXP = rs.getInt("nEXP");
            String sestrategia = rs.getString("sestrategia");
            String shistoria = rs.getString("shistoria");
            int Habitante_ID = rs.getInt("Habitante_ID");

            resultado = new EntrenadorDto(objnEXP, sestrategia, shistoria, Habitante_ID);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}

