package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.HabitanteDto;

public abstract class HabitanteDao implements IDao<HabitanteDto, Integer> {
}
