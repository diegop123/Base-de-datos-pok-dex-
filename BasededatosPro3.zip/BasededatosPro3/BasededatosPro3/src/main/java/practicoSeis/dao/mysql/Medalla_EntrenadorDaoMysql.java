package practicoSeis.dao.mysql;

import practicoSeis.dao.Medalla_EntrenadorDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Medalla_EntrenadorDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Medalla_EntrenadorDaoMysql extends Medalla_EntrenadorDao {
    public Lista<Medalla_EntrenadorDto> get() {
        Lista<Medalla_EntrenadorDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_entrenador, ID_Medalla FROM medalla_entrenador";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_entrenador = rs.getInt("ID_entrenador");
                int ID_Medalla = rs.getInt("ID_Medalla");

                Medalla_EntrenadorDto dto = new Medalla_EntrenadorDto(ID_entrenador, ID_Medalla);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Medalla_EntrenadorDto insert(Medalla_EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO medalla_entrenador (ID_entrenador, ID_Medalla) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_entrenador());
            stmt.setInt(2, obj.getID_Medalla());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Medalla_EntrenadorDto update(Medalla_EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE medalla_entrenador SET ID_Medalla = ? WHERE ID_entrenador = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Medalla());
            stmt.setInt(2, obj.getID_entrenador());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_entrenador) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM medalla_entrenador WHERE ID_entrenador = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_entrenador);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Medalla_EntrenadorDto getById(Integer ID_entrenador) {
        Medalla_EntrenadorDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_entrenador, ID_Medalla FROM medalla_entrenador WHERE ID_entrenador = " + ID_entrenador;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_entrenador = rs.getInt("ID_entrenador");
            int ID_Medalla = rs.getInt("ID_Medalla");

            resultado = new Medalla_EntrenadorDto(objID_entrenador, ID_Medalla);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
