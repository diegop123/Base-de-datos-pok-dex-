package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Entrenador_BatallaDto;

public abstract class Entrenador_BatallaDao implements IDao<Entrenador_BatallaDto,Integer> {
}
