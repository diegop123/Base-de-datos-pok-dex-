package practicoSeis.dao.mysql;

import practicoSeis.dao.Pokemon_EstadisticasDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Pokemon_EstadisticasDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Pokemon_EstadisticasDaoMysql extends Pokemon_EstadisticasDao {
    public Lista<Pokemon_EstadisticasDto> get() {
        Lista<Pokemon_EstadisticasDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas FROM pokemon_estadisticas";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Pokemon = rs.getInt("ID_Pokemon");
                int Nsalud = rs.getInt("Nsalud");
                int Nataque = rs.getInt("Nataque");
                int Ndefensa = rs.getInt("Ndefensa");
                int Nvelocidad = rs.getInt("Nvelocidad");
                String Sestadisticas = rs.getString("Sestadisticas");

                Pokemon_EstadisticasDto dto = new Pokemon_EstadisticasDto(ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Pokemon_EstadisticasDto insert(Pokemon_EstadisticasDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokemon_estadisticas (ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Pokemon());
            stmt.setInt(2, obj.getNsalud());
            stmt.setInt(3, obj.getNataque());
            stmt.setInt(4, obj.getNdefensa());
            stmt.setInt(5, obj.getNvelocidad());
            stmt.setString(6, obj.getSestadisticas());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Pokemon_EstadisticasDto update(Pokemon_EstadisticasDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokemon_estadisticas SET Nsalud = ?, Nataque = ?, Ndefensa = ?, Nvelocidad = ?, Sestadisticas = ? WHERE ID_Pokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getNsalud());
            stmt.setInt(2, obj.getNataque());
            stmt.setInt(3, obj.getNdefensa());
            stmt.setInt(4, obj.getNvelocidad());
            stmt.setString(5, obj.getSestadisticas());
            stmt.setInt(6, obj.getID_Pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Pokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM pokemon_estadisticas WHERE ID_Pokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Pokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Pokemon_EstadisticasDto getById(Integer ID_Pokemon) {
        Pokemon_EstadisticasDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas FROM pokemon_estadisticas WHERE ID_Pokemon = " + ID_Pokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Pokemon = rs.getInt("ID_Pokemon");
            int Nsalud = rs.getInt("Nsalud");
            int Nataque = rs.getInt("Nataque");
            int Ndefensa = rs.getInt("Ndefensa");
            int Nvelocidad = rs.getInt("Nvelocidad");
            String Sestadisticas = rs.getString("Sestadisticas");

            resultado = new Pokemon_EstadisticasDto(objID_Pokemon, Nsalud, Nataque, Ndefensa, Nvelocidad, Sestadisticas);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
