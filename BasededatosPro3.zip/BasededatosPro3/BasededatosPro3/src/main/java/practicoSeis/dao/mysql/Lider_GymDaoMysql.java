package practicoSeis.dao.mysql;


import practicoSeis.dao.Lider_GymDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Lider_GymDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Lider_GymDaoMysql extends Lider_GymDao {
    public Lista<Lider_GymDto> get() {
        Lista<Lider_GymDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT stipo, sestrategia, shabilidad, Habitante_ID, ID_GimnacioPokemon FROM lider_de_gym";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String stipo = rs.getString("stipo");
                String sestrategia = rs.getString("sestrategia");
                String shabilidad = rs.getString("shabilidad");
                int Habitante_ID = rs.getInt("Habitante_ID");
                int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");

                Lider_GymDto dto = new Lider_GymDto(stipo, sestrategia, shabilidad, Habitante_ID, ID_GimnacioPokemon);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Lider_GymDto insert(Lider_GymDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO lider_de_gym (stipo, sestrategia, shabilidad, Habitante_ID, ID_GimnacioPokemon) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getStipo());
            stmt.setString(2, obj.getSestrategia());
            stmt.setString(3, obj.getShabilidad());
            stmt.setInt(4, obj.getHabitante_ID());
            stmt.setInt(5, obj.getID_GimnacioPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Lider_GymDto update(Lider_GymDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE lider_de_gym SET stipo = ?, sestrategia = ?, shabilidad = ?, Habitante_ID = ?, ID_GimnacioPokemon = ? WHERE Habitante_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getStipo());
            stmt.setString(2, obj.getSestrategia());
            stmt.setString(3, obj.getShabilidad());
            stmt.setInt(4, obj.getHabitante_ID());
            stmt.setInt(5, obj.getID_GimnacioPokemon());
            stmt.setInt(6, obj.getHabitante_ID());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer Habitante_ID) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM lider_de_gym WHERE Habitante_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, Habitante_ID);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Lider_GymDto getById(Integer Habitante_ID) {
        Lider_GymDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT stipo, sestrategia, shabilidad, Habitante_ID, ID_GimnacioPokemon FROM lider_de_gym WHERE Habitante_ID = " + Habitante_ID;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            String stipo = rs.getString("stipo");
            String sestrategia = rs.getString("sestrategia");
            String shabilidad = rs.getString("shabilidad");
            int ID_Habitante = rs.getInt("Habitante_ID");
            int ID_GimnacioPokemon = rs.getInt("ID_GimnacioPokemon");

            resultado = new Lider_GymDto(stipo, sestrategia, shabilidad, ID_Habitante, ID_GimnacioPokemon);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
