package practicoSeis.dao.mysql;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import practicoSeis.lista.Lista;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dao.PersonaDao;
import practicoSeis.dto.PersonaDto;

import java.sql.*;

public class PersonaDaoMysql extends PersonaDao {
    private static Logger logger = LogManager.getRootLogger();

    /**
     * Este metodo recupera todos los registros de la tabla "personas" en la base de datos
     * y los devuelve en una lista de objetos "PersonaDto"
     */
    public Lista<PersonaDto> get() {
        Lista<PersonaDto> resultado = new Lista<>(); //Lista vacia para almacenar los resultados
        // Variables para la conexion a la BD
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            // se encarga de crear o recuperar una conexión existente.
            conn = Conexion.obtenerOCrear().conectar(); //Obtiene una conexion a la BD

            String query = "SELECT nID_Batalla, nTurnosFinalizados, sEstado, sGanador, sEventos, nResultado, nDuracion, ID_Entrenador_Batalla, ID_Entrenador FROM pokebatallas.batalla" ;

            stmt = conn.createStatement(); //Crea la consulta
            rs = stmt.executeQuery(query); //Ejecuta la consulta

            while(rs.next()) {

                int objnID_Batalla = rs.getInt("nID_Batalla");
                int objnTurnosFinalizados = rs.getInt("nTurnosFinalizados");
                String objsEstado = rs.getString("sEstado");
                String objsGanador = rs.getString("sGanador");
                String objsEventos = rs.getString("sEventos");
                String objnResultado = rs.getString("nResultado");
                int objnDuracion = rs.getInt("nDuracion");
                int objID_Entrenador_Batalla = rs.getInt("ID_Entrenador_Batalla");
                int objID_Entrenador = rs.getInt("ID_Entrenador");

                // Crea un nuevo objeto PersonaDto con los datos del registro actual.
                PersonaDto dto =
                        new PersonaDto(objnID_Batalla,objnTurnosFinalizados,objsEstado,objsGanador,objsEventos,
                                objnResultado,objnDuracion,objID_Entrenador_Batalla,objID_Entrenador);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            // handle any errors
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
        // Cierra los recursos (ResultSet y Statement) para liberar memoria.
        finally {
            // it is a good idea to release
            // resources in a finally{} block
            // in reverse-order of their creation
            // if they are no-longer needed

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore

                stmt = null;
            }
        }

        return resultado;
    }

    public PersonaDto insert(PersonaDto obj) {
        /**
         * PreparedStatement Prepara la declaración SQL con la consulta definida anteriormente.
         * Esto permite establecer los valores de los parámetros antes de ejecutar la consulta.
         */
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokebatallas.batalla (nID_Batalla, nTurnosFinalizados, sEstado, sGanador, sEventos, nResultado, nDuracion, ID_Entrenador_Batalla, ID_Entrenador) " +
                    " VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getnID_Batalla());
            stmt.setInt(2, obj.getnTurnosFinalizados());
            stmt.setString(3, obj.getsEstado());
            stmt.setString(4, obj.getsGanador());
            stmt.setString(5, obj.getsEventos());
            stmt.setString(6, obj.getnResultado());
            stmt.setInt(7, obj.getnDuracion());
            stmt.setInt(8, obj.getID_Entrenador_Batalla());
            stmt.setInt(9, obj.getID_Entrenador());

            stmt.executeUpdate(); // Ejecuta la declaracion SQL
            return obj;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public PersonaDto update(PersonaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokebatallas.batalla SET nTurnosFinalizados = ?, " +
                    " sEstado = ?, " +
                    " sGanador = ? " +
                    " sEventos = ? " +
                    " nResultado = ? " +
                    " nDuracion = ? " +
                    " ID_Entrenador_Batalla = ? " +
                    " ID_Entrenador = ? " +
                    "WHERE nID_Batalla = ?";

            stmt = conn.prepareStatement(query);
            stmt.setInt(9, obj.getnID_Batalla());
            stmt.setInt(1, obj.getnTurnosFinalizados());
            stmt.setString(2, obj.getsEstado());
            stmt.setString(3, obj.getsGanador());
            stmt.setString(4, obj.getsEventos());
            stmt.setString(5, obj.getnResultado());
            stmt.setInt(6, obj.getnDuracion());
            stmt.setInt(7, obj.getID_Entrenador_Batalla());
            stmt.setInt(8, obj.getID_Entrenador());

            stmt.executeUpdate();
            return obj;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Batalla) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();

            String query = "DELETE FROM pokebatallas.batalla WHERE nID_Batalla = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Batalla);
            stmt.executeUpdate();
            return 1;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public PersonaDto getById(Integer ID_Batalla) {
        PersonaDto resultado = null;
        Connection conn = null;

        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();

            String query = "SELECT nID_Batalla, nTurnosFinalizados, sEstado, sGanador,\n" +
                    "                      sEventos, nResultado, nDuracion, ID_Entrenador_Batalla, ID_Entrenador " +
                    "FROM pokebatallas.batalla " +
                    "WHERE nID_Batalla = " + ID_Batalla;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objnID_Batalla = rs.getInt("nID_Batalla");
            int objnTurnosFinalizados = rs.getInt("nTurnosFinalizados");
            String objsEstado = rs.getString("sEstado");
            String objsGanador = rs.getString("sGanador");
            String objsEventos = rs.getString("sEventos");
            String objnResultado = rs.getString("nResultado");
            int objnDuracion = rs.getInt("nDuracion");
            int objID_Entrenador_Batalla = rs.getInt("ID_Entrenador_Batalla");
            int objID_Entrenador = rs.getInt("ID_Entrenador");

            resultado =
                    new PersonaDto(objnID_Batalla,objnTurnosFinalizados,objsEstado,objsGanador,objsEventos,
                            objnResultado,objnDuracion,objID_Entrenador_Batalla,objID_Entrenador);

        } catch (SQLException ex) {
            // handle any errors
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            resultado = null;
        }
        finally {
            // it is a good idea to release
            // resources in a finally{} block
            // in reverse-order of their creation
            // if they are no-longer needed

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore

                stmt = null;
            }
        }

        return resultado;
    }
}
