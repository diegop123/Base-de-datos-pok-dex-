package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.EquipoPokemon_BatallaDto;

public abstract class EquipoPokemon_BatallaDao implements IDao<EquipoPokemon_BatallaDto, Integer> {
}
