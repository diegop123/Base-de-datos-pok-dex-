package practicoSeis.dao.mysql;

import practicoSeis.dao.PuebloDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.PuebloDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class PuebloDaoMysql {
}
