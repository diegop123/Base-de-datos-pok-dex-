package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.LogrosDto;

public abstract class LogrosDao implements IDao<LogrosDto, Integer> {
}
