package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Pokemon_HabilidadesDto;

public abstract class Pokemon_HabilidadesDao implements IDao<Pokemon_HabilidadesDto, Integer> {
}
