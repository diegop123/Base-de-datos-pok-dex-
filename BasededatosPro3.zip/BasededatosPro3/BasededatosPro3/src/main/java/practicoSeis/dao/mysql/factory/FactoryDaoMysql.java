package practicoSeis.dao.mysql.factory;

import practicoSeis.dao.*;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.*;

public class FactoryDaoMysql extends FactoryDao {
    public FactoryDaoMysql() {

    }
    @Override
    public PersonaDao newPersonaDao() {
        return new PersonaDaoMysql();
    }

    @Override
    public TablaPersonaDao newTablaPersonaDao() {
        return new TablaPersonaMysql();
    }

    @Override
    public EntrenadorDao newEntrenadorDao() {
        return new EntrenadorDaoMysql();
    }

    @Override
    public Entrenador_BatallaDao newEntrenador_BatallaDao() {
        return new Entrenador_BatallaDaoMysql();
    }

    @Override
    public Equipo_PokemonDao newEquipo_PokemonDao() {
        return new Equipo_PokemonDaoMysql();
    }

    @Override
    public EquipoPokemon_BatallaDao newEquipoPokemon_BatallaDao() {
        return new EquipoPokemon_BatallaDaoMysql();
    }

    @Override
    public Gimnasio_PokemonDao newGimnasio_PokemonDao() {
        return new Gimnasio_PokemonDaoMysql();
    }

    @Override
    public GimnasioPokemon_DesafioDao newGimnasioPokemon_DesafioDao() {
        return new GimnasioPokemon_DesafioDaoMysql();
    }

    @Override
    public GimnasioPokemon_LiderDao newGimnasioPokemon_LiderDao() {
        return new GimnasioPokemon_LiderDaoMysql();
    }

    @Override
    public HabitanteDao newHabitanteDao() {
        return new HabitanteDaoMysql();
    }

    @Override
    public Lider_GymDao newLider_GymDao() {
        return new Lider_GymDaoMysql();
    }

    @Override
    public LogrosDao newLogrosDao() {
        return new LogrosDaoMysql();
    }

    @Override
    public Logros_EntrenadorDao newLogros_EntrenadorDao() {
        return new Logros_EntrenadorDaoMysql();
    }

    @Override
    public MedallaDao newMedallaDao() {
        return new MedallaDaoMysql();
    }

    @Override
    public Medalla_EntrenadorDao newMedalla_EntrenadorDao() {
        return new Medalla_EntrenadorDaoMysql();
    }

    @Override
    public Poke_BallDao newPoke_BallDao() {
        return new Poke_BallDaoMysql();
    }

    @Override
    public PokemonDao newPokemonDao() {
        return new PokemonDaoMysql();
    }

    @Override
    public Pokemon_DebilidadesDao newPokemon_DebilidadesDao() {
        return new Pokemon_DebilidadesDaoMysql();
    }

    @Override
    public Pokemon_EstadisticasDao newPokemon_EstadisticasDao() {
        return new Pokemon_EstadisticasDaoMysql();
    }

    @Override
    public Pokemon_EvolucionDao newPokemon_EvolucionDao() {
        return new Pokemon_EvolucionDaoMysql();
    }

    @Override
    public Pokemon_FortalezasDao newPokemon_FortalezasDao() {
        return new Pokemon_FortalezasDaoMysql();
    }

    @Override
    public Pokemon_HabilidadesDao newPokemon_HabilidadesDao() {
        return new Pokemon_HabilidadesDaoMysql();
    }

    @Override
    public PuebloDao newPuebloDao() {
        return null;
    }

    @Override
    public RegionDao newRegionDao() {
        return null;
    }
}
