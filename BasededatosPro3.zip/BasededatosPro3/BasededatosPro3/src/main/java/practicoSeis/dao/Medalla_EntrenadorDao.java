package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Medalla_EntrenadorDto;

public abstract class Medalla_EntrenadorDao implements IDao<Medalla_EntrenadorDto, Integer> {
}
