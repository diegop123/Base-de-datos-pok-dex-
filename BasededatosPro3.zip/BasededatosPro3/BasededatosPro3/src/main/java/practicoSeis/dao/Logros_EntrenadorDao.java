package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Logros_EntrenadorDto;

public abstract class Logros_EntrenadorDao implements IDao<Logros_EntrenadorDto, Integer> {
}
