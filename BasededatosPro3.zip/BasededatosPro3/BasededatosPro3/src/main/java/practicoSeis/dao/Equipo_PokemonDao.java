package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Equipo_PokemonDto;

public abstract class Equipo_PokemonDao implements IDao<Equipo_PokemonDto, Integer> {
}
