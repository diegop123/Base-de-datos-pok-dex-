package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Pokemon_DebilidadesDto;

public abstract class Pokemon_DebilidadesDao implements IDao<Pokemon_DebilidadesDto, Integer> {
}
