package practicoSeis.dao.mysql;

import practicoSeis.dao.Logros_EntrenadorDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Logros_EntrenadorDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Logros_EntrenadorDaoMysql extends Logros_EntrenadorDao {
    public Lista<Logros_EntrenadorDto> get() {
        Lista<Logros_EntrenadorDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Entrenador, ID_Logro FROM logros_entrenador";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Entrenador = rs.getInt("ID_Entrenador");
                int ID_Logro = rs.getInt("ID_Logro");

                Logros_EntrenadorDto dto = new Logros_EntrenadorDto(ID_Entrenador, ID_Logro);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Logros_EntrenadorDto insert(Logros_EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO logros_entrenador (ID_Entrenador, ID_Logro) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Entrenador());
            stmt.setInt(2, obj.getID_Logro());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Logros_EntrenadorDto update(Logros_EntrenadorDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE logros_entrenador SET ID_Logro = ? WHERE ID_Entrenador = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Logro());
            stmt.setInt(2, obj.getID_Entrenador());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Entrenador) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM logros_entrenador WHERE ID_Entrenador = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Entrenador);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Logros_EntrenadorDto getById(Integer ID_Entrenador) {
        Logros_EntrenadorDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Entrenador, ID_Logro FROM logros_entrenador WHERE ID_Entrenador = " + ID_Entrenador;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Entrenador = rs.getInt("ID_Entrenador");
            int ID_Logro = rs.getInt("ID_Logro");

            resultado = new Logros_EntrenadorDto(objID_Entrenador, ID_Logro);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
