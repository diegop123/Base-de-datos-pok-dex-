package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Pokemon_EvolucionDto;

public abstract class Pokemon_EvolucionDao implements IDao<Pokemon_EvolucionDto, Integer> {
}
