package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.Gimnasio_PokemonDto;

public abstract class Gimnasio_PokemonDao implements IDao<Gimnasio_PokemonDto, Integer>  {
}
