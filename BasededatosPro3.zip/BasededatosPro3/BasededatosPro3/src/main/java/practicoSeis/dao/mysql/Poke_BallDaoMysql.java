package practicoSeis.dao.mysql;

import practicoSeis.dao.Poke_BallDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Poke_BallDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Poke_BallDaoMysql extends Poke_BallDao {
    public Lista<Poke_BallDto> get() {
        Lista<Poke_BallDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nProbabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador FROM poke_ball";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int nID = rs.getInt("nID");
                String sTipo = rs.getString("sTipo");
                String sDescripcion = rs.getString("sDescripcion");
                int nCaracteristicas_Especiales = rs.getInt("nCaracteristicas_Especiales");
                int nPropabilidad_de_captura = rs.getInt("nProbabilidad_de_captura");
                String sObtencion = rs.getString("sObtencion");
                String sDiseño = rs.getString("sDiseño");
                int ID_Entrenador = rs.getInt("ID_Entrenador");

                Poke_BallDto dto = new Poke_BallDto(nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nPropabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Poke_BallDto insert(Poke_BallDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO poke_ball (nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nProbabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getnID());
            stmt.setString(2, obj.getsTipo());
            stmt.setString(3, obj.getsDescripcion());
            stmt.setInt(4, obj.getnCaracteristicas_Especiales());
            stmt.setInt(5, obj.getnPropabilidad_de_captura());
            stmt.setString(6, obj.getsObtencion());
            stmt.setString(7, obj.getsDiseño());
            stmt.setInt(8, obj.getID_Entrenador());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Poke_BallDto update(Poke_BallDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE poke_ball SET sTipo = ?, sDescripcion = ?, nCaracteristicas_Especiales = ?, nProbabilidad_de_captura = ?, sObtencion = ?, sDiseño = ?, ID_Entrenador = ? WHERE nID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getsTipo());
            stmt.setString(2, obj.getsDescripcion());
            stmt.setInt(3, obj.getnCaracteristicas_Especiales());
            stmt.setInt(4, obj.getnPropabilidad_de_captura());
            stmt.setString(5, obj.getsObtencion());
            stmt.setString(6, obj.getsDiseño());
            stmt.setInt(7, obj.getID_Entrenador());
            stmt.setInt(8, obj.getnID());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer nID) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM poke_ball WHERE nID = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, nID);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Poke_BallDto getById(Integer nID) {
        Poke_BallDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT nID, sTipo, sDescripcion, nCaracteristicas_Especiales, nProbabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador FROM poke_ball WHERE nID = " + nID;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objnID = rs.getInt("nID");
            String sTipo = rs.getString("sTipo");
            String sDescripcion = rs.getString("sDescripcion");
            int nCaracteristicas_Especiales = rs.getInt("nCaracteristicas_Especiales");
            int nPropabilidad_de_captura = rs.getInt("nProbabilidad_de_captura");
            String sObtencion = rs.getString("sObtencion");
            String sDiseño = rs.getString("sDiseño");
            int ID_Entrenador = rs.getInt("ID_Entrenador");

            resultado = new Poke_BallDto(objnID, sTipo, sDescripcion, nCaracteristicas_Especiales, nPropabilidad_de_captura, sObtencion, sDiseño, ID_Entrenador);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
