package practicoSeis.dao.mysql;

import practicoSeis.dao.PokemonDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.PokemonDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class PokemonDaoMysql extends PokemonDao {
    public Lista<PokemonDto> get() {
        Lista<PokemonDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID FROM pokemon";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Pokemon = rs.getInt("ID_Pokemon");
                String Snombre = rs.getString("Snombre");
                String Stipo = rs.getString("Stipo");
                String Sdescripcion = rs.getString("Sdescripcion");
                String Sestado = rs.getString("Sestado");
                int Habitante_ID = rs.getInt("Habitante_ID");

                PokemonDto dto = new PokemonDto(ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public PokemonDto insert(PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokemon (ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Pokemon());
            stmt.setString(2, obj.getSnombre());
            stmt.setString(3, obj.getStipo());
            stmt.setString(4, obj.getSdescripcion());
            stmt.setString(5, obj.getSestado());
            stmt.setInt(6, obj.getHabitante_ID());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public PokemonDto update(PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokemon SET Snombre = ?, Stipo = ?, Sdescripcion = ?, Sestado = ?, Habitante_ID = ? WHERE ID_Pokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getSnombre());
            stmt.setString(2, obj.getStipo());
            stmt.setString(3, obj.getSdescripcion());
            stmt.setString(4, obj.getSestado());
            stmt.setInt(5, obj.getHabitante_ID());
            stmt.setInt(6, obj.getID_Pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Pokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM pokemon WHERE ID_Pokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Pokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public PokemonDto getById(Integer ID_Pokemon) {
        PokemonDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID FROM pokemon WHERE ID_Pokemon = " + ID_Pokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Pokemon = rs.getInt("ID_Pokemon");
            String Snombre = rs.getString("Snombre");
            String Stipo = rs.getString("Stipo");
            String Sdescripcion = rs.getString("Sdescripcion");
            String Sestado = rs.getString("Sestado");
            int Habitante_ID = rs.getInt("Habitante_ID");

            resultado = new PokemonDto(objID_Pokemon, Snombre, Stipo, Sdescripcion, Sestado, Habitante_ID);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
