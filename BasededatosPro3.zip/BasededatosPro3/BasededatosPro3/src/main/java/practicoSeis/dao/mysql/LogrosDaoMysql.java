package practicoSeis.dao.mysql;

import practicoSeis.dao.LogrosDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.LogrosDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class LogrosDaoMysql extends LogrosDao {

    public Lista<LogrosDto> get() {
        Lista<LogrosDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT registro, nombre, descripcion, dificultad, historial, criterios, recompensa FROM logros";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int registro = rs.getInt("registro");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                int dificultad = rs.getInt("dificultad");
                String historial = rs.getString("historial");
                String criterios = rs.getString("criterios");
                String recompensa = rs.getString("recompensa");

                LogrosDto dto = new LogrosDto(registro, nombre, descripcion, dificultad, historial, criterios, recompensa);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public LogrosDto insert(LogrosDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO logros (registro, nombre, descripcion, dificultad, historial, criterios, recompensa) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getRegistro());
            stmt.setString(2, obj.getNombre());
            stmt.setString(3, obj.getDescripcion());
            stmt.setInt(4, obj.getDificultad());
            stmt.setString(5, obj.getHistorial());
            stmt.setString(6, obj.getCriterios());
            stmt.setString(7, obj.getRecompensa());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public LogrosDto update(LogrosDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE logros SET nombre = ?, descripcion = ?, dificultad = ?, historial = ?, criterios = ?, recompensa = ? WHERE registro = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getNombre());
            stmt.setString(2, obj.getDescripcion());
            stmt.setInt(3, obj.getDificultad());
            stmt.setString(4, obj.getHistorial());
            stmt.setString(5, obj.getCriterios());
            stmt.setString(6, obj.getRecompensa());
            stmt.setInt(7, obj.getRegistro());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer registro) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM logros WHERE registro = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, registro);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public LogrosDto getById(Integer registro) {
        LogrosDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT registro, nombre, descripcion, dificultad, historial, criterios, recompensa FROM logros WHERE registro = " + registro;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objRegistro = rs.getInt("registro");
            String nombre = rs.getString("nombre");
            String descripcion = rs.getString("descripcion");
            int dificultad = rs.getInt("dificultad");
            String historial = rs.getString("historial");
            String criterios = rs.getString("criterios");
            String recompensa = rs.getString("recompensa");

            resultado = new LogrosDto(objRegistro, nombre, descripcion, dificultad, historial, criterios, recompensa);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
