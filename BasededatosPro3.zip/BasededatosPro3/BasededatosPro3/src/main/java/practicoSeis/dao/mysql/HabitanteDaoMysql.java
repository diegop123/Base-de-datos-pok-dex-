package practicoSeis.dao.mysql;

import practicoSeis.dao.HabitanteDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.HabitanteDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class HabitanteDaoMysql extends HabitanteDao {
    public Lista<HabitanteDto> get() {
        Lista<HabitanteDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT CI, Snombre, Ssexo, Nedad, NfechaNam, ID_pueblo FROM habitante";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int CI = rs.getInt("CI");
                String Snombre = rs.getString("Snombre");
                char Ssexo = rs.getString("Ssexo").charAt(0);
                int Nedad = rs.getInt("Nedad");
                Date NfechaNam = rs.getDate("NfechaNam");
                String ID_pueblo = rs.getString("ID_pueblo");

                HabitanteDto dto = new HabitanteDto(CI, Snombre, Ssexo, Nedad, NfechaNam, ID_pueblo);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public HabitanteDto insert(HabitanteDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO habitante (CI, Snombre, Ssexo, Nedad, NfechaNam, ID_pueblo) VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getCI());
            stmt.setString(2, obj.getSnombre());
            stmt.setString(3, String.valueOf(obj.getSsexo()));
            stmt.setInt(4, obj.getNedad());
            stmt.setDate(5, new java.sql.Date(obj.getNfechaNam().getTime()));
            stmt.setString(6, obj.getID_pueblo());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public HabitanteDto update(HabitanteDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE habitante SET Snombre = ?, Ssexo = ?, Nedad = ?, NfechaNam = ?, ID_pueblo = ? WHERE CI = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getSnombre());
            stmt.setString(2, String.valueOf(obj.getSsexo()));
            stmt.setInt(3, obj.getNedad());
            stmt.setDate(4, new java.sql.Date(obj.getNfechaNam().getTime()));
            stmt.setString(5, obj.getID_pueblo());
            stmt.setInt(6, obj.getCI());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer CI) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM habitante WHERE CI = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, CI);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public HabitanteDto getById(Integer CI) {
        HabitanteDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT CI, Snombre, Ssexo, Nedad, NfechaNam, ID_pueblo FROM habitante WHERE CI = " + CI;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objCI = rs.getInt("CI");
            String Snombre = rs.getString("Snombre");
            char Ssexo = rs.getString("Ssexo").charAt(0);
            int Nedad = rs.getInt("Nedad");
            Date NfechaNam = rs.getDate("NfechaNam");
            String ID_pueblo = rs.getString("ID_pueblo");

            resultado = new HabitanteDto(objCI, Snombre, Ssexo, Nedad, NfechaNam, ID_pueblo);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
