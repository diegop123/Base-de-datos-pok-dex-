package practicoSeis.dao;

import practicoSeis.dao.generic.IDao;
import practicoSeis.dto.EntrenadorDto;

public abstract class EntrenadorDao implements IDao<EntrenadorDto,Integer> {

    //public abstract void convertirNombreAMayusculas();
}
