package practicoSeis.dao.mysql;

import practicoSeis.dao.Pokemon_FortalezasDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Pokemon_FortalezasDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Pokemon_FortalezasDaoMysql extends Pokemon_FortalezasDao {
    public Lista<Pokemon_FortalezasDto> get() {
        Lista<Pokemon_FortalezasDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, nFortalezas FROM pokemon_fortalezas";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_Pokemon = rs.getInt("ID_Pokemon");
                int nFortalezas = rs.getInt("nFortalezas");

                Pokemon_FortalezasDto dto = new Pokemon_FortalezasDto(ID_Pokemon, nFortalezas);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Pokemon_FortalezasDto insert(Pokemon_FortalezasDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO pokemon_fortalezas (ID_Pokemon, nFortalezas) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_Pokemon());
            stmt.setInt(2, obj.getnFortalezas());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Pokemon_FortalezasDto update(Pokemon_FortalezasDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE pokemon_fortalezas SET nFortalezas = ? WHERE ID_Pokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getnFortalezas());
            stmt.setInt(2, obj.getID_Pokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_Pokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM pokemon_fortalezas WHERE ID_Pokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_Pokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Pokemon_FortalezasDto getById(Integer ID_Pokemon) {
        Pokemon_FortalezasDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_Pokemon, nFortalezas FROM pokemon_fortalezas WHERE ID_Pokemon = " + ID_Pokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_Pokemon = rs.getInt("ID_Pokemon");
            int nFortalezas = rs.getInt("nFortalezas");

            resultado = new Pokemon_FortalezasDto(objID_Pokemon, nFortalezas);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
