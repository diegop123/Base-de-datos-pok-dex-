package practicoSeis.dao.mysql;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dao.TablaPersonaDao;
import practicoSeis.dto.TablaPersonaDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class TablaPersonaMysql extends TablaPersonaDao {
    private static Logger logger = LogManager.getRootLogger();

    /**
     * Este metodo recupera todos los registros de la tabla "personas" en la base de datos
     * y los devuelve en una lista de objetos "PersonaDto"
     */
    public Lista<TablaPersonaDto> get() {
        Lista<TablaPersonaDto> resultado = new Lista<>(); //Lista vacia para almacenar los resultados
        // Variables para la conexion a la BD
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            // se encarga de crear o recuperar una conexión existente.
            conn = Conexion.obtenerOCrear().conectar(); //Obtiene una conexion a la BD

            String query = "SELECT id, nombre, alturacm, pesokg FROM personas";
            stmt = conn.createStatement(); //Crea la consulta
            rs = stmt.executeQuery(query); //Ejecuta la consulta

            while (rs.next()) {
                int objId = rs.getInt("id");
                String objNombre = rs.getString("nombre");
                int objAlturacm = rs.getInt("alturacm");
                float objPesokg = rs.getFloat("pesokg");

                // Crea un nuevo objeto PersonaDto con los datos del registro actual.
                TablaPersonaDto dto =
                        new TablaPersonaDto(objId, objNombre, objAlturacm, objPesokg);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            // handle any errors
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
        // Cierra los recursos (ResultSet y Statement) para liberar memoria.
        finally {
            // it is a good idea to release
            // resources in a finally{} block
            // in reverse-order of their creation
            // if they are no-longer needed

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {
                } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {
                } // ignore

                stmt = null;
            }
        }

        return resultado;
    }
    public TablaPersonaDto insert(TablaPersonaDto obj) {
        /**
         * PreparedStatement Prepara la declaración SQL con la consulta definida anteriormente.
         * Esto permite establecer los valores de los parámetros antes de ejecutar la consulta.
         */
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO personas (id,nombre, alturacm, pesokg) " +
                    " VALUES ( ?, ?, ?, ? )"; // Son los valores que estan en el objeto como argumento

            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getId());
            stmt.setString(2, obj.getNombre());
            stmt.setInt(3, obj.getAlturacm());
            stmt.setFloat(4, obj.getPesokg());

            stmt.executeUpdate(); // Ejecuta la declaracion SQL
            return obj;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public TablaPersonaDto update(TablaPersonaDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE personas SET nombre = ?, " +
                    " alturacm = ?, " +
                    " pesokg = ? " +
                    "WHERE id = ?";

            stmt = conn.prepareStatement(query);
            stmt.setInt(4, obj.getId());
            stmt.setString(1, obj.getNombre());
            stmt.setInt(2, obj.getAlturacm());
            stmt.setFloat(3, obj.getPesokg());

            stmt.executeUpdate();
            return obj;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer id) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();

            String query = "DELETE FROM personas WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return 1;
        } catch(SQLException ex) {
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public TablaPersonaDto getById(Integer id) {
        TablaPersonaDto resultado = null;
        Connection conn = null;

        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();

            String query = "SELECT id, nombre, alturacm, pesokg " +
                    "FROM personas " +
                    "WHERE id = " + id;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();
            int objId = rs.getInt("id");
            String objNombre = rs.getString("nombre");
            int objAlturacm = rs.getInt("alturacm");
            float objPesokg = rs.getFloat("pesokg");

            resultado =
                    new TablaPersonaDto(objId,objNombre,objAlturacm, objPesokg);

        } catch (SQLException ex) {
            // handle any errors
            logger.info("SQLException: " + ex.getMessage());
            logger.info("SQLState: " + ex.getSQLState());
            logger.info("VendorError: " + ex.getErrorCode());
            resultado = null;
        }
        finally {
            // it is a good idea to release
            // resources in a finally{} block
            // in reverse-order of their creation
            // if they are no-longer needed

            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) { } // ignore

                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) { } // ignore

                stmt = null;
            }
        }

        return resultado;
    }
}

