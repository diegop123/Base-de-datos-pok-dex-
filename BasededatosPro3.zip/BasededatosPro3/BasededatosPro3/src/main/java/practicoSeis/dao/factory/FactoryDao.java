package practicoSeis.dao.factory;

import practicoSeis.dao.*;
import practicoSeis.dao.mysql.factory.FactoryDaoMysql;

public abstract class FactoryDao {
    private static FactoryDao instancia = null;

    public static FactoryDao obtenerOCrear() {
        if (instancia == null) {
            instancia = new FactoryDaoMysql();
        }
        return instancia;
    }

    public abstract PersonaDao newPersonaDao();
    public abstract TablaPersonaDao newTablaPersonaDao();
    public abstract EntrenadorDao newEntrenadorDao();
    public abstract Entrenador_BatallaDao newEntrenador_BatallaDao();
    public abstract Equipo_PokemonDao newEquipo_PokemonDao();
    public abstract EquipoPokemon_BatallaDao newEquipoPokemon_BatallaDao();
    public abstract Gimnasio_PokemonDao newGimnasio_PokemonDao();
    public abstract GimnasioPokemon_DesafioDao newGimnasioPokemon_DesafioDao();
    public abstract GimnasioPokemon_LiderDao newGimnasioPokemon_LiderDao();
    public abstract HabitanteDao newHabitanteDao();
    public abstract Lider_GymDao newLider_GymDao();
    public abstract LogrosDao newLogrosDao();
    public abstract Logros_EntrenadorDao newLogros_EntrenadorDao();
    public abstract MedallaDao newMedallaDao();
    public abstract Medalla_EntrenadorDao newMedalla_EntrenadorDao();
    public abstract Poke_BallDao newPoke_BallDao();
    public abstract PokemonDao newPokemonDao();
    public abstract Pokemon_DebilidadesDao newPokemon_DebilidadesDao();
    public abstract Pokemon_EstadisticasDao newPokemon_EstadisticasDao();
    public abstract Pokemon_EvolucionDao newPokemon_EvolucionDao();
    public abstract Pokemon_FortalezasDao newPokemon_FortalezasDao();
    public abstract Pokemon_HabilidadesDao newPokemon_HabilidadesDao();
    public abstract PuebloDao newPuebloDao();
    public abstract RegionDao newRegionDao();

}
