package practicoSeis.dao.mysql;


import practicoSeis.dao.Gimnasio_PokemonDao;
import practicoSeis.dao.conexion.Conexion;
import practicoSeis.dto.Gimnasio_PokemonDto;
import practicoSeis.lista.Lista;

import java.sql.*;

public class Gimnasio_PokemonDaoMysql extends Gimnasio_PokemonDao {
    public Lista<Gimnasio_PokemonDto> get() {
        Lista<Gimnasio_PokemonDto> resultado = new Lista<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, snombre, ncaracteristicas_espaciales, ID_pueblo FROM gimnasio_pokemon";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int ID_GimnasioPokemon = rs.getInt("ID_GimnacioPokemon");
                String snombre = rs.getString("snombre");
                int ncaracteristicas_espaciales = rs.getInt("ncaracteristicas_espaciales");
                String ID_pueblo = rs.getString("ID_pueblo");

                Gimnasio_PokemonDto dto = new Gimnasio_PokemonDto(ID_GimnasioPokemon, snombre, ncaracteristicas_espaciales, ID_pueblo);
                resultado.insert(dto);
            }
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }

    public Gimnasio_PokemonDto insert(Gimnasio_PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "INSERT INTO gimnasio_pokemon (ID_GimnacioPokemon, snombre, ncaracteristicas_espaciales, ID_pueblo) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, obj.getID_GimnasioPokemon());
            stmt.setString(2, obj.getSnombre());
            stmt.setInt(3, obj.getNcaracteristicas_espaciales());
            stmt.setString(4, obj.getID_pueblo());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public Gimnasio_PokemonDto update(Gimnasio_PokemonDto obj) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "UPDATE gimnasio_pokemon SET snombre = ?, ncaracteristicas_espaciales = ?, ID_pueblo = ? WHERE ID_GimnacioPokemon = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, obj.getSnombre());
            stmt.setInt(2, obj.getNcaracteristicas_espaciales());
            stmt.setString(3, obj.getID_pueblo());
            stmt.setInt(4, obj.getID_GimnasioPokemon());
            stmt.executeUpdate();
            return obj;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return null;
        }
    }

    public int delete(Integer ID_GimnasioPokemon) {
        try {
            Connection conn = Conexion.obtenerOCrear().conectar();
            String query = "DELETE FROM gimnasio_pokemon WHERE ID_GimnacioPokemon = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, ID_GimnasioPokemon);
            stmt.executeUpdate();
            return 1;
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            return 0;
        }
    }

    public Gimnasio_PokemonDto getById(Integer ID_GimnasioPokemon) {
        Gimnasio_PokemonDto resultado = null;
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexion.obtenerOCrear().conectar();
            String query = "SELECT ID_GimnacioPokemon, snombre, ncaracteristicas_espaciales, ID_pueblo FROM gimnasio_pokemon WHERE ID_GimnacioPokemon = " + ID_GimnasioPokemon;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            rs.next();

            int objID_GimnasioPokemon = rs.getInt("ID_GimnacioPokemon");
            String snombre = rs.getString("snombre");
            int ncaracteristicas_espaciales = rs.getInt("ncaracteristicas_espaciales");
            String ID_pueblo = rs.getString("ID_pueblo");

            resultado = new Gimnasio_PokemonDto(objID_GimnasioPokemon, snombre, ncaracteristicas_espaciales, ID_pueblo);
        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
            resultado = null;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException sqlEx) {}
                rs = null;
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException sqlEx) {}
                stmt = null;
            }
        }
        return resultado;
    }
}
