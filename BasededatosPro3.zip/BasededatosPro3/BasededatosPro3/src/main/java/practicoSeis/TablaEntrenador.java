package practicoSeis;

import practicoSeis.dao.EntrenadorDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.EntrenadorDaoMysql;
import practicoSeis.dto.EntrenadorDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaEntrenador extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private EntrenadorDao  dao = FactoryDao.obtenerOCrear().newEntrenadorDao();

    public TablaEntrenador() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

// Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"nEXP", "sestrategia", "shistoria", "Habitante_ID"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        EntrenadorDaoMysql dao = new EntrenadorDaoMysql();
        Lista<EntrenadorDto> personas = dao.get();

        for (EntrenadorDto persona : personas) {
            Object[] rowData = {
                    persona.getnEXP(),
                    persona.getSestrategia(),
                    persona.getShistoria(),
                    persona.getHabitante_ID()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object Habitante_ID = tableModel.getValueAt(selectedRow, 3);

            testDelete((Integer) Habitante_ID); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String nEXPStr = JOptionPane.showInputDialog(null, "Por favor, introduce nEXP:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (nEXPStr == null || nEXPStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún nEXP.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sestrategia = JOptionPane.showInputDialog(null, "Por favor, introduce sestrategia:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (sestrategia == null || sestrategia.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna sestrategia.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String shistoria = JOptionPane.showInputDialog(null, "Por favor, introduce shistoria:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (shistoria == null || shistoria.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ninguna shistoria.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Habitante_IDStr = JOptionPane.showInputDialog(null, "Por favor, introduce Habitante_ID:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Habitante_IDStr == null || Habitante_IDStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Habitante_ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int nEXP;
        int Habitante_ID;

        try {
            nEXP = Integer.parseInt(nEXPStr);
            Habitante_ID = Integer.parseInt(Habitante_IDStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        EntrenadorDto entrenadorExistente = dao.getById(Habitante_ID);
        // Verificar si el Habitante_ID ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El Habitante_ID ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el Habitante_ID ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 3) == Habitante_ID) {
                JOptionPane.showMessageDialog(null, "El Habitante_ID ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(nEXP, sestrategia, shistoria, Habitante_ID);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{nEXP, sestrategia, shistoria, Habitante_ID});
    }

    public void testDelete(int Habitante_ID) {
        EntrenadorDao dao = FactoryDao.obtenerOCrear().newEntrenadorDao();
        dao.delete(Habitante_ID);
    }

    public void testInsert(int nEXP, String sestrategia, String shistoria, int Habitante_ID) {
        EntrenadorDao dao = FactoryDao.obtenerOCrear().newEntrenadorDao();
        EntrenadorDto nuevo = new EntrenadorDto(nEXP, sestrategia, shistoria, Habitante_ID);
        dao.insert(nuevo);
    }
}

