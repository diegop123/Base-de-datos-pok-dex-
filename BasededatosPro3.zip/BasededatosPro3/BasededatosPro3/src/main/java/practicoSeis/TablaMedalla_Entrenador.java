package practicoSeis;


import practicoSeis.dao.Medalla_EntrenadorDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.Medalla_EntrenadorDaoMysql;
import practicoSeis.dto.Medalla_EntrenadorDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaMedalla_Entrenador extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private Medalla_EntrenadorDao dao = FactoryDao.obtenerOCrear().newMedalla_EntrenadorDao();

    public TablaMedalla_Entrenador() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_entrenador", "ID_Medalla"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Medalla_EntrenadorDaoMysql dao = new Medalla_EntrenadorDaoMysql();
        Lista<Medalla_EntrenadorDto> personas = dao.get();

        for (Medalla_EntrenadorDto persona : personas) {
            Object[] rowData = {
                    persona.getID_entrenador(),
                    persona.getID_Medalla()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_entrenador = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_entrenador); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String ID_entrenadorStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_entrenador:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_entrenadorStr == null || ID_entrenadorStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_entrenador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ID_MedallaStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_Medalla:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_MedallaStr == null || ID_MedallaStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_Medalla.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int ID_entrenador;
        int ID_Medalla;

        try {
            ID_entrenador = Integer.parseInt(ID_entrenadorStr);
            ID_Medalla = Integer.parseInt(ID_MedallaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Medalla_EntrenadorDto entrenadorExistente = dao.getById(ID_entrenador);
        // Verificar si el ID_entrenador ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_entrenador ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_entrenador ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == ID_entrenador) {
                JOptionPane.showMessageDialog(null, "El ID_entrenador ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(ID_entrenador, ID_Medalla);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{ID_entrenador, ID_Medalla});
    }

    public void testDelete(int ID_entrenador) {
        Medalla_EntrenadorDao dao = FactoryDao.obtenerOCrear().newMedalla_EntrenadorDao();
        dao.delete(ID_entrenador);
    }

    public void testInsert(int ID_entrenador, int ID_Medalla) {
        Medalla_EntrenadorDao dao = FactoryDao.obtenerOCrear().newMedalla_EntrenadorDao();
        Medalla_EntrenadorDto nuevo = new Medalla_EntrenadorDto(ID_entrenador, ID_Medalla);
        dao.insert(nuevo);
    }
}
