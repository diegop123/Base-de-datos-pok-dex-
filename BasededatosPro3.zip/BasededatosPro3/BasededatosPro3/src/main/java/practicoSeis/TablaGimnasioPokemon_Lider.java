package practicoSeis;


import practicoSeis.dao.GimnasioPokemon_LiderDao;
import practicoSeis.dao.factory.FactoryDao;
import practicoSeis.dao.mysql.GimnasioPokemon_LiderDaoMysql;
import practicoSeis.dto.GimnasioPokemon_LiderDto;
import practicoSeis.lista.Lista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TablaGimnasioPokemon_Lider extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private GimnasioPokemon_LiderDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_LiderDao();

    public TablaGimnasioPokemon_Lider() {
        Interfaz Interfaz = new Interfaz();

        setTitle("POKEDEX");
        setSize(1200, 600);
        setResizable(true);
        this.setJMenuBar(Interfaz.menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Crear el modelo de la tabla con las columnas correspondientes
        tableModel = new DefaultTableModel(new Object[]{"ID_GimnacioPokemon", "Pokemon_del_lider"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        GimnasioPokemon_LiderDaoMysql dao = new GimnasioPokemon_LiderDaoMysql();
        Lista<GimnasioPokemon_LiderDto> personas = dao.get();

        for (GimnasioPokemon_LiderDto persona : personas) {
            Object[] rowData = {
                    persona.getID_GimnacioPokemon(),
                    persona.getPokemon_del_lider()
            };
            tableModel.addRow(rowData);
        }

        // Crear la tabla con el modelo
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Crear el botón para agregar filas
        JButton agregar = new JButton("Agregar");
        agregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearFILA();
            }
        });

        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrarfila();
            }
        });

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(agregar);
        buttonPanel.add(eliminar);

        // Añadir la tabla y el panel del botón al JFrame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public void borrarfila() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Object ID_GimnacioPokemon = tableModel.getValueAt(selectedRow, 0);

            testDelete((Integer) ID_GimnacioPokemon); // Llamar al método estático testDelete
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void crearFILA() {
        String ID_GimnacioPokemonStr = JOptionPane.showInputDialog(null, "Por favor, introduce ID_GimnacioPokemon:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (ID_GimnacioPokemonStr == null || ID_GimnacioPokemonStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún ID_GimnacioPokemon.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String Pokemon_del_lider = JOptionPane.showInputDialog(null, "Por favor, introduce Pokemon_del_lider:", "Entrada", JOptionPane.QUESTION_MESSAGE);
        if (Pokemon_del_lider == null || Pokemon_del_lider.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se ingresó ningún Pokemon_del_lider.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convertir las entradas a los tipos adecuados
        int ID_GimnacioPokemon;

        try {
            ID_GimnacioPokemon = Integer.parseInt(ID_GimnacioPokemonStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Los valores ingresados deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        GimnasioPokemon_LiderDto entrenadorExistente = dao.getById(ID_GimnacioPokemon);
        // Verificar si el ID_GimnacioPokemon ya existe en la base de datos
        if (entrenadorExistente != null) {
            JOptionPane.showMessageDialog(null, "El ID_GimnacioPokemon ingresado ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verificar si el ID_GimnacioPokemon ya existe en el tableModel
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((int) tableModel.getValueAt(i, 0) == ID_GimnacioPokemon) {
                JOptionPane.showMessageDialog(null, "El ID_GimnacioPokemon ingresado ya existe en la tabla.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Insertar en la base de datos
        testInsert(ID_GimnacioPokemon, Pokemon_del_lider);

        // Agregar fila a la tabla
        tableModel.addRow(new Object[]{ID_GimnacioPokemon, Pokemon_del_lider});
    }

    public void testDelete(int ID_GimnacioPokemon) {
        GimnasioPokemon_LiderDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_LiderDao();
        dao.delete(ID_GimnacioPokemon);
    }

    public void testInsert(int ID_GimnacioPokemon, String Pokemon_del_lider) {
        GimnasioPokemon_LiderDao dao = FactoryDao.obtenerOCrear().newGimnasioPokemon_LiderDao();
        GimnasioPokemon_LiderDto nuevo = new GimnasioPokemon_LiderDto(ID_GimnacioPokemon, Pokemon_del_lider);
        dao.insert(nuevo);
    }
}
