package practicoSeis;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Interfaz extends JFrame  {

    JMenuBar menuBar = new JMenuBar();
    JMenu Tablas = new JMenu("Tablas");
    JMenuItem Persona = new JMenuItem("Batalla");
    JMenuItem entrenador = new JMenuItem("entrenador");
    JMenuItem entrenadorBatalla = new JMenuItem("entrenadorBatalla");
    JMenuItem equipoPokemon = new JMenuItem("equipoPokemon");
    JMenuItem equipoPokemonBatalla = new JMenuItem("equipoPokemonBatalla");
    JMenuItem gimnasioPokemon = new JMenuItem("gimnasioPokemon");
    JMenuItem gimnasioPokemonDesafio = new JMenuItem("gimnasioPokemonDesafio");
    JMenuItem gimnasioPokemonLider = new JMenuItem("gimnasioPokemonLider");
    JMenuItem habitante = new JMenuItem("habitante");
    JMenuItem liderDeGym = new JMenuItem("liderDeGym");
    JMenuItem logros = new JMenuItem("logros");
    JMenuItem logrosEntrenador = new JMenuItem("logrosEntrenador");
    JMenuItem medalla = new JMenuItem("medalla");
    JMenuItem medallaEntrenador = new JMenuItem("medallaEntrenador");
    JMenuItem pokeBall = new JMenuItem("pokeBall");
    JMenuItem pokemon = new JMenuItem("pokemon");
    JMenuItem pokemonDebilidades = new JMenuItem("pokemonDebilidades");
    JMenuItem pokemonEstadisticas = new JMenuItem("pokemonEstadisticas");
    JMenuItem pokemonEvolucion = new JMenuItem("pokemonEvolucion");
    JMenuItem pokemonFortalezas = new JMenuItem("pokemonFortalezas");
    JMenuItem pokemonHabilidades = new JMenuItem("pokemonHabilidades");
    JMenuItem pueblo = new JMenuItem("pueblo");
    JMenuItem region = new JMenuItem("region");
    JMenuItem tablaPersona = new JMenuItem("tablaPersona");


    public Interfaz() {
        setTitle("POKEDEX");
        setSize(1200, 600);

        menuBar.add(Tablas);
        Tablas.add(Persona);
        Tablas.add(entrenador);
        Tablas.add(entrenadorBatalla);
        Tablas.add(equipoPokemon);
        Tablas.add(equipoPokemonBatalla);
        Tablas.add(gimnasioPokemon);
        Tablas.add(gimnasioPokemonDesafio);
        Tablas.add(gimnasioPokemonLider);
        Tablas.add(habitante);
        Tablas.add(liderDeGym);
        Tablas.add(logros);
        Tablas.add(logrosEntrenador);
        Tablas.add(medalla);
        Tablas.add(medallaEntrenador);
        Tablas.add(pokeBall);
        Tablas.add(pokemon);
        Tablas.add(pokemonDebilidades);
        Tablas.add(pokemonEstadisticas);
        Tablas.add(pokemonEvolucion);
        Tablas.add(pokemonFortalezas);
        Tablas.add(pokemonHabilidades);
        //Tablas.add(pueblo);
        //Tablas.add(region);
        Tablas.add(tablaPersona);



        this.setJMenuBar(menuBar);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        Persona.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaUno(e);
            }
        });
        entrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDos(e);
            }
        });
        entrenadorBatalla.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaTres(e);
            }
        });
        equipoPokemon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaCuatro(e);
            }
        });
        equipoPokemonBatalla.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaCinco(e);
            }
        });
        gimnasioPokemon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaSeis(e);
            }
        });
        gimnasioPokemonDesafio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaSiete(e);
            }
        });
        gimnasioPokemonLider.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaOcho(e);
            }
        });
        habitante.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaNueve(e);
            }
        });
        liderDeGym.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDiez(e);
            }
        });
        logros.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaOnce(e);
            }
        });
        logrosEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDoce(e);
            }
        });
        medalla.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaTrece(e);
            }
        });
        medallaEntrenador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaCatorce(e);
            }
        });
        pokeBall.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaQuince(e);
            }
        });
        pokemon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDieciseis(e);
            }
        });
        pokemonDebilidades.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDieciSiete(e);
            }
        });
        pokemonEstadisticas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDieciOcho(e);
            }
        });
        pokemonEvolucion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaDieciNueve(e);
            }
        });
        pokemonFortalezas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaVeinte(e);
            }
        });
        pokemonHabilidades.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaVeintiUno(e);
            }
        });
        pueblo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaVeintiDos(e);
            }
        });
        region.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaVeintitres(e);
            }
        });


        tablaPersona.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tablaPersona(e);
            }
        });


    }


    private void tablaUno(ActionEvent e){
        TablaBatalla tabla1 = new TablaBatalla();
        setVisible(false);
        tabla1.setVisible(true);
        tabla1.setLocationRelativeTo(null);

    }
    private void tablaDos(ActionEvent e){
        TablaEntrenador tabla2 = new TablaEntrenador();
        setVisible(false);
        tabla2.setVisible(true);
        tabla2.setLocationRelativeTo(null);

    }
    private void tablaTres(ActionEvent e){
        TablaEntrenador_Batalla tabla3 = new TablaEntrenador_Batalla();
        setVisible(false);
        tabla3.setVisible(true);
        tabla3.setLocationRelativeTo(null);

    }
    private void tablaCuatro(ActionEvent e){
        TablaEquipo_Pokemon tabla4 = new TablaEquipo_Pokemon();
        setVisible(false);
        tabla4.setVisible(true);
        tabla4.setLocationRelativeTo(null);

    }
    private void tablaCinco(ActionEvent e){
        TablaEquipoPokemon_Batalla tabla5 = new TablaEquipoPokemon_Batalla();
        setVisible(false);
        tabla5.setVisible(true);
        tabla5.setLocationRelativeTo(null);

    }
    private void tablaSeis(ActionEvent e){
        TablaGimnasio_Pokemon tabla6 = new TablaGimnasio_Pokemon();
        setVisible(false);
        tabla6.setVisible(true);
        tabla6.setLocationRelativeTo(null);
    }
    private void tablaSiete(ActionEvent e){
        TablaGimnasioPokemon_Desafio tabla7 = new TablaGimnasioPokemon_Desafio();
        setVisible(false);
        tabla7.setVisible(true);
        tabla7.setLocationRelativeTo(null);
    }
    private void tablaOcho(ActionEvent e){
        TablaGimnasioPokemon_Lider tabla8 = new TablaGimnasioPokemon_Lider();
        setVisible(false);
        tabla8.setVisible(true);
        tabla8.setLocationRelativeTo(null);
    }
    private void tablaNueve(ActionEvent e){
        TablaHabitante tabla9 = new TablaHabitante();
        setVisible(false);
        tabla9.setVisible(true);
        tabla9.setLocationRelativeTo(null);
    }
    private void tablaDiez(ActionEvent e){
        TablaLider_Gym tabla10 = new TablaLider_Gym();
        setVisible(false);
        tabla10.setVisible(true);
        tabla10.setLocationRelativeTo(null);
    }
    private void tablaOnce(ActionEvent e){
        TablaLogros tabla11 = new TablaLogros();
        setVisible(false);
        tabla11.setVisible(true);
        tabla11.setLocationRelativeTo(null);
    }
    private void tablaDoce(ActionEvent e){
        TablaLogros_Entrenador tabla12 = new TablaLogros_Entrenador();
        setVisible(false);
        tabla12.setVisible(true);
        tabla12.setLocationRelativeTo(null);
    }
    private void tablaTrece(ActionEvent e){
        TablaMedalla tabla13 = new TablaMedalla();
        setVisible(false);
        tabla13.setVisible(true);
        tabla13.setLocationRelativeTo(null);
    }
    private void tablaCatorce(ActionEvent e){
        TablaMedalla_Entrenador tabla14 = new TablaMedalla_Entrenador();
        setVisible(false);
        tabla14.setVisible(true);
        tabla14.setLocationRelativeTo(null);
    }
    private void tablaQuince(ActionEvent e){
        TablaPoke_ball tabla15 = new TablaPoke_ball();
        setVisible(false);
        tabla15.setVisible(true);
        tabla15.setLocationRelativeTo(null);
    }
    private void tablaDieciseis(ActionEvent e){
        TablaPokemon tabla16 = new TablaPokemon();
        setVisible(false);
        tabla16.setVisible(true);
        tabla16.setLocationRelativeTo(null);
    }
    private void tablaDieciSiete(ActionEvent e){
        TablaPokemon_Debilidades tabla17 = new TablaPokemon_Debilidades();
        setVisible(false);
        tabla17.setVisible(true);
        tabla17.setLocationRelativeTo(null);
    }
    private void tablaDieciOcho(ActionEvent e){
        TablaPokemon_Estadisticas tabla18 = new TablaPokemon_Estadisticas();
        setVisible(false);
        tabla18.setVisible(true);
        tabla18.setLocationRelativeTo(null);
    }
    private void tablaDieciNueve(ActionEvent e){
        TablaPokemon_Evolucion tabla19 = new TablaPokemon_Evolucion();
        setVisible(false);
        tabla19.setVisible(true);
        tabla19.setLocationRelativeTo(null);
    }
    private void tablaVeinte(ActionEvent e){
        TablaPokemon_Fortalezas tabla20 = new TablaPokemon_Fortalezas();
        setVisible(false);
        tabla20.setVisible(true);
        tabla20.setLocationRelativeTo(null);
    }
    private void tablaVeintiUno(ActionEvent e){
        TablaPokemon_Habilidades tabla21 = new TablaPokemon_Habilidades();
        setVisible(false);
        tabla21.setVisible(true);
        tabla21.setLocationRelativeTo(null);
    }
    private void tablaVeintiDos(ActionEvent e){

    }
    private void tablaVeintitres(ActionEvent e){

    }

    private void tablaPersona(ActionEvent e){
        TablaPersonaInterfaz tablaPersonaInterfaz = new TablaPersonaInterfaz();
        setVisible(false);
        tablaPersonaInterfaz.setVisible(true);
        tablaPersonaInterfaz.setLocationRelativeTo(null);


    }


    public static void main(String[] args) {
        Interfaz Interfaz = new Interfaz();
        Interfaz.setVisible(true);
        Interfaz.setLocationRelativeTo(null);
    }
}
